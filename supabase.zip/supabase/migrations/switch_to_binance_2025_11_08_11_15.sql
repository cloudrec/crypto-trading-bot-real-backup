-- Изменяем настройки на Binance для тестирования
UPDATE trading_settings 
SET exchange = 'binance'
WHERE user_id = 'a5b7bab7-74c0-47f3-a0df-c5de4b071ce4';