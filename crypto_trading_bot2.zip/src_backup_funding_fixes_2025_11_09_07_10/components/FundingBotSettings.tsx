import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Bot, TrendingUp, TrendingDown, Clock, Shield, Bell, Calendar } from 'lucide-react';

interface FundingBotSettings {
  id?: string;
  enabled: boolean;
  entry_strategy: 'short_first' | 'long_first';
  min_funding_rate: number;
  position_size_usd: number;
  scan_interval_minutes: number;
  exchanges: string[];
  max_positions: number;
  stop_loss_percent: number;
  take_profit_percent: number;
  telegram_notifications: boolean;
  telegram_chat_id?: string;
  work_schedule_enabled: boolean;
  work_start_hour: number;
  work_end_hour: number;
}

const defaultSettings: FundingBotSettings = {
  enabled: false,
  entry_strategy: 'short_first',
  min_funding_rate: 0.5,
  position_size_usd: 100,
  scan_interval_minutes: 30,
  exchanges: ['binance', 'bybit', 'gate'],
  max_positions: 3,
  stop_loss_percent: 5.0,
  take_profit_percent: 2.0,
  telegram_notifications: true,
  work_schedule_enabled: false,
  work_start_hour: 0,
  work_end_hour: 23,
};

export default function FundingBotSettings() {
  const [settings, setSettings] = useState<FundingBotSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('funding_bot_settings_2025_11_09_06_55')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading funding bot settings:', error);
        return;
      }

      if (data) {
        setSettings({
          ...data,
          exchanges: data.exchanges || ['binance', 'bybit', 'gate'],
        });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const settingsToSave = {
        ...settings,
        user_id: user.id,
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase
        .from('funding_bot_settings_2025_11_09_06_55')
        .upsert(settingsToSave);

      if (error) throw error;

      toast({
        title: "✅ Настройки сохранены",
        description: "Настройки фандинг бота успешно обновлены",
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "❌ Ошибка сохранения",
        description: "Не удалось сохранить настройки",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const toggleExchange = (exchange: string) => {
    setSettings(prev => ({
      ...prev,
      exchanges: prev.exchanges.includes(exchange)
        ? prev.exchanges.filter(e => e !== exchange)
        : [...prev.exchanges, exchange]
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Заголовок */}
      <div className="flex items-center gap-3">
        <Bot className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">Автоторговля (Фандинг бот)</h1>
          <p className="text-muted-foreground">
            Автоматическая торговля на основе ставок финансирования
          </p>
        </div>
      </div>

      {/* Основные настройки */}
      <Card className="trading-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Основные настройки
          </CardTitle>
          <CardDescription>
            Включение и базовая конфигурация фандинг бота
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Включение бота */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-base font-medium">Включить фандинг бот</Label>
              <p className="text-sm text-muted-foreground">
                Автоматическое размещение ордеров на основе фандинга
              </p>
            </div>
            <Switch
              checked={settings.enabled}
              onCheckedChange={(enabled) => setSettings(prev => ({ ...prev, enabled }))}
            />
          </div>

          <Separator />

          {/* Стратегия входа */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Логика входа после начисления фандинга
            </Label>
            <Select
              value={settings.entry_strategy}
              onValueChange={(value: 'short_first' | 'long_first') => 
                setSettings(prev => ({ ...prev, entry_strategy: value }))
              }
            >
              <SelectTrigger className="vision-input">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="short_first">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="h-4 w-4 text-red-500" />
                    Сначала ШОРТ, потом ЛОНГ
                  </div>
                </SelectItem>
                <SelectItem value="long_first">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    Сначала ЛОНГ, потом ШОРТ
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              {settings.entry_strategy === 'short_first' 
                ? '📉 При положительном фандинге открываем ШОРТ, при отрицательном - ЛОНГ'
                : '📈 При положительном фандинге открываем ЛОНГ, при отрицательном - ШОРТ'
              }
            </p>
          </div>

          {/* Минимальный фандинг */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Минимальный фандинг (%)</Label>
            <Input
              type="number"
              step="0.1"
              min="0.1"
              max="10"
              value={settings.min_funding_rate}
              onChange={(e) => setSettings(prev => ({ 
                ...prev, 
                min_funding_rate: parseFloat(e.target.value) || 0.5 
              }))}
              className="vision-input"
            />
            <p className="text-sm text-muted-foreground">
              Минимальная ставка фандинга для входа в позицию
            </p>
          </div>

          {/* Размер позиции */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Размер позиции (USD)</Label>
            <Input
              type="number"
              min="10"
              max="10000"
              value={settings.position_size_usd}
              onChange={(e) => setSettings(prev => ({ 
                ...prev, 
                position_size_usd: parseInt(e.target.value) || 100 
              }))}
              className="vision-input"
            />
            <p className="text-sm text-muted-foreground">
              Размер каждой позиции в долларах США
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Настройки сканирования */}
      <Card className="trading-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Настройки сканирования
          </CardTitle>
          <CardDescription>
            Частота проверки и выбор бирж для мониторинга
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Интервал сканирования */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Интервал сканирования (минуты)</Label>
            <Select
              value={settings.scan_interval_minutes.toString()}
              onValueChange={(value) => setSettings(prev => ({ 
                ...prev, 
                scan_interval_minutes: parseInt(value) 
              }))}
            >
              <SelectTrigger className="vision-input">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15 минут</SelectItem>
                <SelectItem value="30">30 минут</SelectItem>
                <SelectItem value="60">1 час</SelectItem>
                <SelectItem value="120">2 часа</SelectItem>
                <SelectItem value="240">4 часа</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Выбор бирж */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Биржи для сканирования</Label>
            <div className="flex flex-wrap gap-2">
              {['binance', 'bybit', 'gate'].map((exchange) => (
                <Badge
                  key={exchange}
                  variant={settings.exchanges.includes(exchange) ? "default" : "outline"}
                  className="cursor-pointer px-3 py-1"
                  onClick={() => toggleExchange(exchange)}
                >
                  {exchange.toUpperCase()}
                  {settings.exchanges.includes(exchange) && ' ✓'}
                </Badge>
              ))}
            </div>
            <p className="text-sm text-muted-foreground">
              Выберите биржи для мониторинга ставок фандинга
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Управление рисками */}
      <Card className="trading-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Управление рисками
          </CardTitle>
          <CardDescription>
            Настройки безопасности и ограничения
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Максимум позиций */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Максимум открытых позиций</Label>
            <Input
              type="number"
              min="1"
              max="10"
              value={settings.max_positions}
              onChange={(e) => setSettings(prev => ({ 
                ...prev, 
                max_positions: parseInt(e.target.value) || 3 
              }))}
              className="vision-input"
            />
          </div>

          {/* Стоп-лосс */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Стоп-лосс (%)</Label>
            <Input
              type="number"
              step="0.5"
              min="1"
              max="20"
              value={settings.stop_loss_percent}
              onChange={(e) => setSettings(prev => ({ 
                ...prev, 
                stop_loss_percent: parseFloat(e.target.value) || 5.0 
              }))}
              className="vision-input"
            />
          </div>

          {/* Тейк-профит */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Тейк-профит (%)</Label>
            <Input
              type="number"
              step="0.5"
              min="0.5"
              max="10"
              value={settings.take_profit_percent}
              onChange={(e) => setSettings(prev => ({ 
                ...prev, 
                take_profit_percent: parseFloat(e.target.value) || 2.0 
              }))}
              className="vision-input"
            />
          </div>
        </CardContent>
      </Card>

      {/* Уведомления */}
      <Card className="trading-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Уведомления
          </CardTitle>
          <CardDescription>
            Настройки Telegram уведомлений
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Telegram уведомления */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-base font-medium">Telegram уведомления</Label>
              <p className="text-sm text-muted-foreground">
                Получать уведомления о действиях бота
              </p>
            </div>
            <Switch
              checked={settings.telegram_notifications}
              onCheckedChange={(telegram_notifications) => 
                setSettings(prev => ({ ...prev, telegram_notifications }))
              }
            />
          </div>

          {settings.telegram_notifications && (
            <div className="space-y-3">
              <Label className="text-base font-medium">Telegram Chat ID</Label>
              <Input
                type="text"
                placeholder="@username или chat_id"
                value={settings.telegram_chat_id || ''}
                onChange={(e) => setSettings(prev => ({ 
                  ...prev, 
                  telegram_chat_id: e.target.value 
                }))}
                className="vision-input"
              />
              <p className="text-sm text-muted-foreground">
                Ваш Telegram username или chat ID для уведомлений
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Расписание работы */}
      <Card className="trading-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Расписание работы
          </CardTitle>
          <CardDescription>
            Ограничение времени работы бота
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Включение расписания */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="text-base font-medium">Ограничить время работы</Label>
              <p className="text-sm text-muted-foreground">
                Бот будет работать только в указанные часы
              </p>
            </div>
            <Switch
              checked={settings.work_schedule_enabled}
              onCheckedChange={(work_schedule_enabled) => 
                setSettings(prev => ({ ...prev, work_schedule_enabled }))
              }
            />
          </div>

          {settings.work_schedule_enabled && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-3">
                <Label className="text-base font-medium">Начало работы (час)</Label>
                <Input
                  type="number"
                  min="0"
                  max="23"
                  value={settings.work_start_hour}
                  onChange={(e) => setSettings(prev => ({ 
                    ...prev, 
                    work_start_hour: parseInt(e.target.value) || 0 
                  }))}
                  className="vision-input"
                />
              </div>
              <div className="space-y-3">
                <Label className="text-base font-medium">Конец работы (час)</Label>
                <Input
                  type="number"
                  min="0"
                  max="23"
                  value={settings.work_end_hour}
                  onChange={(e) => setSettings(prev => ({ 
                    ...prev, 
                    work_end_hour: parseInt(e.target.value) || 23 
                  }))}
                  className="vision-input"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Кнопки управления */}
      <div className="flex gap-4">
        <Button 
          onClick={saveSettings} 
          disabled={saving}
          className="btn-vision-primary flex-1"
        >
          {saving ? 'Сохранение...' : '💾 Сохранить настройки'}
        </Button>
        
        <Button 
          variant="outline" 
          onClick={loadSettings}
          className="btn-vision-secondary"
        >
          🔄 Сбросить
        </Button>
      </div>

      {/* Статус бота */}
      <Card className="trading-card">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${settings.enabled ? 'bg-green-500' : 'bg-gray-400'}`} />
              <span className="font-medium">
                Статус: {settings.enabled ? '🟢 Активен' : '🔴 Отключен'}
              </span>
            </div>
            <Badge variant={settings.enabled ? "default" : "secondary"}>
              {settings.enabled ? 'РАБОТАЕТ' : 'ОСТАНОВЛЕН'}
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}