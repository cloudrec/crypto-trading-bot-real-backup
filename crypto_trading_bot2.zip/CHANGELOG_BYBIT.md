# CHANGELOG - BYBIT (ОБНОВЛЕНО)

## v15 (2025-11-09 15:50) - КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ
### ✅ ИСПРАВЛЕНО
- **КРИТИЧНО:** Исправлена проблема SHORT → LONG
- Добавлен параметр `order_type` в функцию `handleBybitOrder`
- Правильное определение направления:
  - LONG: `side: 'Buy'` 
  - SHORT: `side: 'Sell'`
- Правильный расчет TP/SL цен для SHORT позиций
- Встроенные TP/SL в основной ордер

### 🔧 Edge Function
- `bybit_fixed_long_short_2025_11_09_15_50`
- Поддерживает: LONG/SHORT с правильными направлениями
- Статус: ✅ ИСПРАВЛЕНО

### 📊 Логика направлений
```javascript
const isLong = orderType === 'LONG';
const side = isLong ? 'Buy' : 'Sell';

// TP/SL цены
if (isLong) {
  tpPrice = currentPrice * 1.02; // +2%
  slPrice = currentPrice * 0.98; // -2%
} else {
  tpPrice = currentPrice * 0.98; // -2% для SHORT
  slPrice = currentPrice * 1.02; // +2% для SHORT
}

// Встроенные TP/SL в ордер
const orderParams = {
  category: 'linear',
  symbol: symbol,
  side: side,
  orderType: 'Market',
  qty: qty,
  takeProfit: tpPrice,
  stopLoss: slPrice
};
```

## v14 (2025-11-09 15:30)
### ✅ Исправления
- Исправлены ложные ошибки при успешном размещении ордеров
- Улучшена обработка ответов API

### ❌ Известные проблемы (ИСПРАВЛЕНО в v15)
- SHORT кнопка ставила LONG позицию

## Предыдущие версии
- v13: Проверка статуса ордера
- v12: Поддержка LONG/SHORT (с ошибкой направления)
- v7-v11: Эволюция TP/SL подходов
- v1-v6: Базовая реализация Bybit API