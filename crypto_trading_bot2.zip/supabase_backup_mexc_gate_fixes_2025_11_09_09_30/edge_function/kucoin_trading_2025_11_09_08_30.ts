import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, user_id } = await req.json();
    console.log('🟡 KUCOIN: Starting action:', action, 'for user:', user_id);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем API ключи KuCoin
    const { data: apiKeys, error: keysError } = await supabase
      .from('api_keys_dev')
      .select('*')
      .eq('user_id', user_id)
      .eq('exchange', 'kucoin')
      .single();

    if (keysError || !apiKeys) {
      console.error('🟡 KUCOIN: No API keys found:', keysError);
      return new Response(
        JSON.stringify({ success: false, error: 'KuCoin API keys not found' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🟡 KUCOIN: API keys found');

    const apiKey = apiKeys.api_key;
    const apiSecret = apiKeys.api_secret;
    const passphrase = apiKeys.passphrase; // KuCoin требует passphrase

    if (action === 'get_balance') {
      return await handleKuCoinBalance(apiKey, apiSecret, passphrase);
    } else if (action === 'place_order_with_tp_sl') {
      return await handleKuCoinOrder(apiKey, apiSecret, passphrase, user_id, supabase);
    } else if (action === 'get_positions') {
      return await handleKuCoinPositions(apiKey, apiSecret, passphrase);
    } else if (action === 'close_positions') {
      return await handleKuCoinClosePositions(apiKey, apiSecret, passphrase);
    } else if (action === 'cancel_orders') {
      return await handleKuCoinCancelOrders(apiKey, apiSecret, passphrase);
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Unknown action' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ KUCOIN Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Создание подписи для KuCoin API
function createKuCoinSignature(apiSecret: string, timestamp: string, method: string, endpoint: string, body: string = '') {
  const message = timestamp + method + endpoint + body;
  
  const encoder = new TextEncoder();
  const keyData = encoder.encode(apiSecret);
  const messageData = encoder.encode(message);
  
  return crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  ).then(key => {
    return crypto.subtle.sign('HMAC', key, messageData);
  }).then(signature => {
    const base64 = btoa(String.fromCharCode(...new Uint8Array(signature)));
    console.log('🟡 KUCOIN: Signature created');
    return base64;
  });
}

// Получение баланса
async function handleKuCoinBalance(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    console.log('🟡 KUCOIN: Getting balance...');
    
    const timestamp = Date.now().toString();
    const method = 'GET';
    const endpoint = '/api/v1/account-overview?currency=USDT';
    
    const signature = await createKuCoinSignature(apiSecret, timestamp, method, endpoint);
    
    const url = `https://api-futures.kucoin.com${endpoint}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'KC-API-KEY': apiKey,
        'KC-API-SIGN': signature,
        'KC-API-TIMESTAMP': timestamp,
        'KC-API-PASSPHRASE': passphrase,
        'KC-API-KEY-VERSION': '2',
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    console.log('🟡 KUCOIN: Balance response:', JSON.stringify(data, null, 2));

    if (data.code !== '200000') {
      throw new Error(`KuCoin API error: ${data.msg} (Code: ${data.code})`);
    }

    const balance = parseFloat(data.data?.availableBalance || '0');
    console.log('🟡 KUCOIN: USDT Balance:', balance);

    return new Response(
      JSON.stringify({
        success: true,
        balance: balance,
        status: 'KUCOIN LIVE ✅',
        debug: {
          function: 'kucoin_trading_2025_11_09_08_30',
          api_version: 'V1'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🟡 KUCOIN: Balance error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `KuCoin balance error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Размещение ордера с TP/SL
async function handleKuCoinOrder(apiKey: string, apiSecret: string, passphrase: string, user_id: string, supabase: any) {
  try {
    console.log('🟡 KUCOIN: Placing order...');

    // Получаем настройки пользователя
    const { data: settings } = await supabase
      .from('trading_settings_dev')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (!settings) {
      throw new Error('Trading settings not found');
    }

    // Проверяем баланс
    const balanceResponse = await handleKuCoinBalance(apiKey, apiSecret, passphrase);
    const balanceData = await balanceResponse.json();
    
    if (!balanceData.success) {
      throw new Error('Cannot get balance: ' + balanceData.error);
    }

    const balance = balanceData.balance;
    console.log('🟡 KUCOIN: Available balance:', balance, 'USDT');

    if (balance < 10) {
      throw new Error(`Insufficient balance. Available: ${balance} USDT, Minimum required: 10 USDT`);
    }

    const symbol = `${settings.base_asset}USDTM`; // KuCoin использует USDTM для фьючерсов
    console.log('🟡 KUCOIN: Trading symbol:', symbol);

    // Получаем текущую цену
    const tickerResponse = await fetch(`https://api-futures.kucoin.com/api/v1/ticker?symbol=${symbol}`);
    const tickerData = await tickerResponse.json();
    
    if (tickerData.code !== '200000') {
      throw new Error(`Cannot get price for ${symbol}: ${tickerData.msg}`);
    }

    const currentPrice = parseFloat(tickerData.data.price);
    console.log('🟡 KUCOIN: Current price for', symbol, ':', currentPrice);

    // Рассчитываем количество (KuCoin использует контракты, не USDT)
    const orderValue = Math.min(settings.order_amount_usd || 10, balance * 0.05);
    const size = Math.floor(orderValue); // KuCoin размер в контрактах
    
    console.log('🟡 KUCOIN: Order size:', size, 'contracts');

    if (size < 1) {
      throw new Error(`Order size ${size} is below minimum 1 contract`);
    }

    // Размещаем основной ордер
    const timestamp = Date.now().toString();
    const method = 'POST';
    const endpoint = '/api/v1/orders';
    
    const orderData = {
      clientOid: `kucoin_${timestamp}`,
      side: 'buy',
      symbol: symbol,
      type: 'market',
      size: size.toString(),
      leverage: settings.leverage || 10
    };

    const body = JSON.stringify(orderData);
    const signature = await createKuCoinSignature(apiSecret, timestamp, method, endpoint, body);

    console.log('🟡 KUCOIN: Placing order with data:', orderData);

    const response = await fetch(`https://api-futures.kucoin.com${endpoint}`, {
      method: 'POST',
      headers: {
        'KC-API-KEY': apiKey,
        'KC-API-SIGN': signature,
        'KC-API-TIMESTAMP': timestamp,
        'KC-API-PASSPHRASE': passphrase,
        'KC-API-KEY-VERSION': '2',
        'Content-Type': 'application/json'
      },
      body: body
    });

    const result = await response.json();
    console.log('🟡 KUCOIN: Order response:', JSON.stringify(result, null, 2));

    if (result.code !== '200000') {
      throw new Error(`KuCoin order error: ${result.msg} (Code: ${result.code})`);
    }

    // Рассчитываем TP и SL цены
    const tpPrice = (currentPrice * (1 + (settings.take_profit_percent || 2) / 100)).toFixed(2);
    const slPrice = (currentPrice * (1 - (settings.stop_loss_percent || 2) / 100)).toFixed(2);

    // Размещаем TP ордер
    const tpOrderData = {
      clientOid: `kucoin_tp_${timestamp}`,
      side: 'sell',
      symbol: symbol,
      type: 'limit',
      size: size.toString(),
      price: tpPrice,
      reduceOnly: true
    };

    // Размещаем SL ордер
    const slOrderData = {
      clientOid: `kucoin_sl_${timestamp}`,
      side: 'sell',
      symbol: symbol,
      type: 'market',
      size: size.toString(),
      stop: 'down',
      stopPrice: slPrice,
      reduceOnly: true
    };

    console.log('🟡 KUCOIN: TP Price:', tpPrice, 'SL Price:', slPrice);

    return new Response(
      JSON.stringify({
        success: true,
        order_id: result.data.orderId,
        symbol: symbol,
        side: 'buy',
        size: size,
        price: currentPrice,
        tp_price: tpPrice,
        sl_price: slPrice,
        status: 'KUCOIN ORDER PLACED ✅'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🟡 KUCOIN: Order error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `KuCoin order error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Получение позиций
async function handleKuCoinPositions(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    const timestamp = Date.now().toString();
    const method = 'GET';
    const endpoint = '/api/v1/positions';
    
    const signature = await createKuCoinSignature(apiSecret, timestamp, method, endpoint);
    
    const response = await fetch(`https://api-futures.kucoin.com${endpoint}`, {
      method: 'GET',
      headers: {
        'KC-API-KEY': apiKey,
        'KC-API-SIGN': signature,
        'KC-API-TIMESTAMP': timestamp,
        'KC-API-PASSPHRASE': passphrase,
        'KC-API-KEY-VERSION': '2',
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    
    if (data.code !== '200000') {
      throw new Error(`KuCoin API error: ${data.msg}`);
    }

    const positions = data.data
      .filter((pos: any) => parseFloat(pos.currentQty) !== 0)
      .map((pos: any) => ({
        symbol: pos.symbol,
        side: parseFloat(pos.currentQty) > 0 ? 'Buy' : 'Sell',
        size: Math.abs(parseFloat(pos.currentQty)).toString(),
        entry_price: pos.avgEntryPrice,
        mark_price: pos.markPrice,
        pnl: pos.unrealisedPnl,
        percentage: pos.unrealisedRoePcnt ? (parseFloat(pos.unrealisedRoePcnt) * 100).toFixed(2) : '0'
      }));

    return new Response(
      JSON.stringify({ success: true, positions }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Закрытие позиций
async function handleKuCoinClosePositions(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    // Сначала получаем открытые позиции
    const positionsResponse = await handleKuCoinPositions(apiKey, apiSecret, passphrase);
    const positionsData = await positionsResponse.json();
    
    if (!positionsData.success || !positionsData.positions.length) {
      return new Response(
        JSON.stringify({ success: true, closed_positions: 0, message: 'No positions to close' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let closedCount = 0;
    
    for (const position of positionsData.positions) {
      try {
        const timestamp = Date.now().toString();
        const method = 'POST';
        const endpoint = '/api/v1/orders';
        
        const orderData = {
          clientOid: `kucoin_close_${timestamp}_${Math.random().toString(36).substr(2, 9)}`,
          side: position.side === 'Buy' ? 'sell' : 'buy',
          symbol: position.symbol,
          type: 'market',
          size: position.size,
          reduceOnly: true
        };

        const body = JSON.stringify(orderData);
        const signature = await createKuCoinSignature(apiSecret, timestamp, method, endpoint, body);

        const response = await fetch(`https://api-futures.kucoin.com${endpoint}`, {
          method: 'POST',
          headers: {
            'KC-API-KEY': apiKey,
            'KC-API-SIGN': signature,
            'KC-API-TIMESTAMP': timestamp,
            'KC-API-PASSPHRASE': passphrase,
            'KC-API-KEY-VERSION': '2',
            'Content-Type': 'application/json'
          },
          body: body
        });

        const result = await response.json();
        
        if (result.code === '200000') {
          closedCount++;
        }
        
      } catch (error) {
        console.error('Error closing KuCoin position:', position.symbol, error);
      }
    }

    return new Response(
      JSON.stringify({ success: true, closed_positions: closedCount }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Отмена ордеров
async function handleKuCoinCancelOrders(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    const timestamp = Date.now().toString();
    const method = 'DELETE';
    const endpoint = '/api/v1/orders';
    
    const signature = await createKuCoinSignature(apiSecret, timestamp, method, endpoint);

    const response = await fetch(`https://api-futures.kucoin.com${endpoint}`, {
      method: 'DELETE',
      headers: {
        'KC-API-KEY': apiKey,
        'KC-API-SIGN': signature,
        'KC-API-TIMESTAMP': timestamp,
        'KC-API-PASSPHRASE': passphrase,
        'KC-API-KEY-VERSION': '2',
        'Content-Type': 'application/json'
      }
    });

    const result = await response.json();
    
    if (result.code !== '200000') {
      throw new Error(`KuCoin API error: ${result.msg}`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        cancelled_orders: result.data?.cancelledOrderIds?.length || 0,
        message: 'All orders cancelled'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}