import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

const TELEGRAM_BOT_TOKEN = '8580424708:AAGH3b4O9JB4YCcW8HS25nIPubHpEkEabgs';
const TELEGRAM_CHAT_ID = '5498907359';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('📡 FUNDING SCANNER STARTED - ИСПРАВЛЕННАЯ ВЕРСИЯ');
    
    // Сканируем все биржи на фандинг > 0.5%
    const fundingResults = await scanAllExchangesFunding();
    
    console.log('📡 SCAN RESULTS:', {
      total_found: fundingResults.length,
      opportunities: fundingResults.slice(0, 3) // Показываем первые 3
    });
    
    // Отправляем результаты в Telegram (всегда)
    await sendFundingToTelegram(fundingResults);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Найдено ${fundingResults.length} возможностей фандинга`,
        funding_opportunities: fundingResults
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ FUNDING SCANNER Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

async function scanAllExchangesFunding() {
  console.log('📡 Scanning funding rates from all exchanges...');
  
  const allOpportunities = [];

  try {
    // 1. Binance Futures - ИСПРАВЛЕННЫЕ КРИТЕРИИ
    console.log('📡 Scanning Binance...');
    const binanceResponse = await fetch('https://fapi.binance.com/fapi/v1/premiumIndex');
    
    if (binanceResponse.ok) {
      const binanceData = await binanceResponse.json();
      console.log('📡 Binance data received:', binanceData.length, 'pairs');
      
      const binanceOpportunities = binanceData
        .filter((item: any) => {
          const rate = parseFloat(item.lastFundingRate);
          const ratePercent = Math.abs(rate * 100); // Берем абсолютное значение
          return ratePercent > 0.5; // > 0.5%
        })
        .map((item: any) => ({
          exchange: 'Binance',
          symbol: item.symbol,
          funding_rate: (parseFloat(item.lastFundingRate) * 100).toFixed(3),
          funding_rate_abs: Math.abs(parseFloat(item.lastFundingRate) * 100).toFixed(3),
          next_funding_time: new Date(parseInt(item.nextFundingTime)).toISOString(),
          link: `https://www.binance.com/ru/futures/${item.symbol.replace('USDT', '_USDT')}`
        }))
        .sort((a: any, b: any) => parseFloat(b.funding_rate_abs) - parseFloat(a.funding_rate_abs))
        .slice(0, 5); // Топ 5

      console.log('📡 Binance opportunities found:', binanceOpportunities.length);
      allOpportunities.push(...binanceOpportunities);
    }

    // 2. Bybit - ИСПРАВЛЕННЫЕ КРИТЕРИИ
    console.log('📡 Scanning Bybit...');
    const bybitResponse = await fetch('https://api.bybit.com/v5/market/tickers?category=linear');
    
    if (bybitResponse.ok) {
      const bybitData = await bybitResponse.json();
      console.log('📡 Bybit response code:', bybitData.retCode);
      
      if (bybitData.retCode === 0) {
        const bybitOpportunities = bybitData.result.list
          .filter((item: any) => {
            const rate = parseFloat(item.fundingRate || '0');
            const ratePercent = Math.abs(rate * 100); // Берем абсолютное значение
            return ratePercent > 0.5; // > 0.5%
          })
          .map((item: any) => ({
            exchange: 'Bybit',
            symbol: item.symbol,
            funding_rate: (parseFloat(item.fundingRate || '0') * 100).toFixed(3),
            funding_rate_abs: Math.abs(parseFloat(item.fundingRate || '0') * 100).toFixed(3),
            next_funding_time: new Date(parseInt(item.nextFundingTime || '0')).toISOString(),
            link: `https://www.bybit.com/trade/usdt/${item.symbol}`
          }))
          .sort((a: any, b: any) => parseFloat(b.funding_rate_abs) - parseFloat(a.funding_rate_abs))
          .slice(0, 5); // Топ 5

        console.log('📡 Bybit opportunities found:', bybitOpportunities.length);
        allOpportunities.push(...bybitOpportunities);
      }
    }

    // 3. Gate.io - ИСПРАВЛЕННЫЕ КРИТЕРИИ
    console.log('📡 Scanning Gate.io...');
    const gateResponse = await fetch('https://api.gateio.ws/api/v4/futures/usdt/tickers');
    
    if (gateResponse.ok) {
      const gateData = await gateResponse.json();
      console.log('📡 Gate.io data received:', gateData.length, 'pairs');
      
      const gateOpportunities = gateData
        .filter((item: any) => {
          const rate = parseFloat(item.funding_rate || '0');
          const ratePercent = Math.abs(rate * 100); // Берем абсолютное значение
          return ratePercent > 0.5; // > 0.5%
        })
        .map((item: any) => ({
          exchange: 'Gate',
          symbol: item.contract,
          funding_rate: (parseFloat(item.funding_rate || '0') * 100).toFixed(3),
          funding_rate_abs: Math.abs(parseFloat(item.funding_rate || '0') * 100).toFixed(3),
          next_funding_time: new Date(parseInt(item.funding_time || '0') * 1000).toISOString(),
          link: `https://www.gate.io/trade/${item.contract}`
        }))
        .sort((a: any, b: any) => parseFloat(b.funding_rate_abs) - parseFloat(a.funding_rate_abs))
        .slice(0, 5); // Топ 5

      console.log('📡 Gate.io opportunities found:', gateOpportunities.length);
      allOpportunities.push(...gateOpportunities);
    }

  } catch (error) {
    console.error('❌ Funding scan error:', error.message);
  }

  // Сортируем все возможности по убыванию абсолютного фандинга
  const sortedOpportunities = allOpportunities
    .sort((a: any, b: any) => parseFloat(b.funding_rate_abs) - parseFloat(a.funding_rate_abs))
    .slice(0, 10); // Топ 10 общих
    
  console.log('📡 FINAL RESULTS:', {
    total_opportunities: sortedOpportunities.length,
    top_3: sortedOpportunities.slice(0, 3).map(o => ({
      exchange: o.exchange,
      symbol: o.symbol,
      rate: o.funding_rate + '%'
    }))
  });

  return sortedOpportunities;
}

async function sendFundingToTelegram(opportunities: any[]) {
  console.log('📱 Sending funding opportunities to Telegram...');
  
  const currentTime = new Date().toLocaleString('ru-RU', { 
    timeZone: 'Europe/Moscow',
    hour: '2-digit',
    minute: '2-digit'
  });

  let message;
  
  if (opportunities.length === 0) {
    // Сообщение когда нет возможностей
    message = `🔍 *СКАН ФАНДИНГА* (${currentTime})\n\n`;
    message += `🚨 Нет возможностей > 0.5%\n\n`;
    message += `📉 Просканировано: Binance, Bybit, Gate\n`;
    message += `⏰ Следующий скан через 10 минут`;
  } else {
    // Сообщение когда есть возможности
    message = `🚀 *ФАНДИНГ ВОЗМОЖНОСТИ* (${currentTime})\n\n`;
    message += `💰 Найдено ${opportunities.length} возможностей > 0.5%\n\n`;

    opportunities.forEach((opp: any, index: number) => {
      const emoji = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '💎';
      const rateDisplay = parseFloat(opp.funding_rate) >= 0 ? `+${opp.funding_rate}` : opp.funding_rate;
      message += `${emoji} *${opp.exchange}* - ${opp.symbol}\n`;
      message += `📈 Фандинг: *${rateDisplay}%*\n`;
      message += `🔗 [Торговать](${opp.link})\n\n`;
    });

    message += `⏰ Следующее сканирование через 10 минут`;
  }

  try {
    const telegramResponse = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text: message,
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })
    });

    if (telegramResponse.ok) {
      console.log('✅ Telegram message sent successfully');
    } else {
      const errorText = await telegramResponse.text();
      console.error('❌ Telegram send error:', errorText);
    }
  } catch (error) {
    console.error('❌ Telegram error:', error.message);
  }
}