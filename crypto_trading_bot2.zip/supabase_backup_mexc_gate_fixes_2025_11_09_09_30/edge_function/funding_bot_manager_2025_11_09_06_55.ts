import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, user_id } = await req.json();
    
    console.log('🤖 FUNDING BOT: Starting action:', action, 'for user:', user_id);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем настройки фандинг бота
    const { data: botSettings, error: settingsError } = await supabase
      .from('funding_bot_settings_2025_11_09_06_55')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (settingsError || !botSettings) {
      console.log('🤖 FUNDING BOT: No bot settings found');
      return new Response(
        JSON.stringify({ success: false, error: 'Настройки фандинг бота не найдены' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🤖 FUNDING BOT: Bot settings loaded:', {
      enabled: botSettings.enabled,
      strategy: botSettings.entry_strategy,
      min_funding: botSettings.min_funding_rate
    });

    // Обработка разных действий
    switch (action) {
      case 'scan_funding':
        return await scanFundingRates(supabase, botSettings);
      
      case 'execute_trade':
        return await executeFundingTrade(supabase, botSettings, user_id);
      
      case 'get_bot_status':
        return await getBotStatus(supabase, botSettings);
      
      case 'stop_bot':
        return await stopBot(supabase, user_id);
      
      default:
        return new Response(
          JSON.stringify({ success: false, error: `Неизвестное действие: ${action}` }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }

  } catch (error) {
    console.error('❌ FUNDING BOT Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Сканирование ставок фандинга
async function scanFundingRates(supabase: any, botSettings: any) {
  console.log('🤖 FUNDING BOT: Scanning funding rates');
  
  if (!botSettings.enabled) {
    return new Response(
      JSON.stringify({
        success: false,
        error: 'Фандинг бот отключен'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  const results = [];
  
  // Сканируем каждую биржу
  for (const exchange of botSettings.exchanges) {
    try {
      console.log(`🤖 FUNDING BOT: Scanning ${exchange}`);
      
      let fundingData = [];
      
      if (exchange === 'binance') {
        fundingData = await scanBinanceFunding(botSettings.min_funding_rate);
      } else if (exchange === 'bybit') {
        fundingData = await scanBybitFunding(botSettings.min_funding_rate);
      } else if (exchange === 'gate') {
        fundingData = await scanGateFunding(botSettings.min_funding_rate);
      }
      
      results.push({
        exchange,
        funding_opportunities: fundingData,
        count: fundingData.length
      });
      
    } catch (error) {
      console.error(`🤖 FUNDING BOT: Error scanning ${exchange}:`, error);
      results.push({
        exchange,
        error: error.message,
        count: 0
      });
    }
  }

  console.log('🤖 FUNDING BOT: Scan completed:', results);

  return new Response(
    JSON.stringify({
      success: true,
      data: {
        scan_time: new Date().toISOString(),
        results,
        total_opportunities: results.reduce((sum, r) => sum + (r.count || 0), 0),
        bot_settings: {
          strategy: botSettings.entry_strategy,
          min_funding: botSettings.min_funding_rate,
          position_size: botSettings.position_size_usd
        }
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

// Сканирование Binance
async function scanBinanceFunding(minRate: number) {
  try {
    const response = await fetch('https://fapi.binance.com/fapi/v1/premiumIndex');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.lastFundingRate) * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.lastFundingRate) * 100).toFixed(3),
        next_funding_time: item.nextFundingTime,
        mark_price: parseFloat(item.markPrice),
        exchange: 'binance'
      }))
      .slice(0, 10); // Топ 10 возможностей
  } catch (error) {
    console.error('Error scanning Binance funding:', error);
    return [];
  }
}

// Сканирование Bybit
async function scanBybitFunding(minRate: number) {
  try {
    const response = await fetch('https://api.bybit.com/v5/market/tickers?category=linear');
    const data = await response.json();
    
    if (data.retCode !== 0) return [];
    
    return data.result.list
      .filter((item: any) => {
        const rate = parseFloat(item.fundingRate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.fundingRate || '0') * 100).toFixed(3),
        mark_price: parseFloat(item.markPrice || '0'),
        exchange: 'bybit'
      }))
      .slice(0, 10);
  } catch (error) {
    console.error('Error scanning Bybit funding:', error);
    return [];
  }
}

// Сканирование Gate.io
async function scanGateFunding(minRate: number) {
  try {
    const response = await fetch('https://api.gateio.ws/api/v4/futures/usdt/tickers');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.funding_rate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.contract,
        funding_rate: (parseFloat(item.funding_rate || '0') * 100).toFixed(3),
        mark_price: parseFloat(item.mark_price || '0'),
        exchange: 'gate'
      }))
      .slice(0, 10);
  } catch (error) {
    console.error('Error scanning Gate funding:', error);
    return [];
  }
}

// Выполнение торговли на основе фандинга
async function executeFundingTrade(supabase: any, botSettings: any, user_id: string) {
  console.log('🤖 FUNDING BOT: Executing funding trade');
  
  if (!botSettings.enabled) {
    return new Response(
      JSON.stringify({
        success: false,
        error: 'Фандинг бот отключен'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  // Проверяем расписание работы
  if (botSettings.work_schedule_enabled) {
    const currentHour = new Date().getHours();
    if (currentHour < botSettings.work_start_hour || currentHour > botSettings.work_end_hour) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Бот работает только в указанные часы'
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  }

  // Здесь будет логика выполнения торговли
  // Пока возвращаем заглушку
  return new Response(
    JSON.stringify({
      success: true,
      data: {
        message: 'Функция торговли в разработке',
        strategy: botSettings.entry_strategy,
        position_size: botSettings.position_size_usd
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

// Получение статуса бота
async function getBotStatus(supabase: any, botSettings: any) {
  console.log('🤖 FUNDING BOT: Getting bot status');
  
  return new Response(
    JSON.stringify({
      success: true,
      data: {
        enabled: botSettings.enabled,
        strategy: botSettings.entry_strategy,
        min_funding_rate: botSettings.min_funding_rate,
        position_size_usd: botSettings.position_size_usd,
        scan_interval_minutes: botSettings.scan_interval_minutes,
        exchanges: botSettings.exchanges,
        max_positions: botSettings.max_positions,
        telegram_notifications: botSettings.telegram_notifications,
        work_schedule_enabled: botSettings.work_schedule_enabled,
        last_scan: new Date().toISOString(),
        status: botSettings.enabled ? 'АКТИВЕН' : 'ОТКЛЮЧЕН'
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

// Остановка бота
async function stopBot(supabase: any, user_id: string) {
  console.log('🤖 FUNDING BOT: Stopping bot');
  
  try {
    const { error } = await supabase
      .from('funding_bot_settings_2025_11_09_06_55')
      .update({ 
        enabled: false,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', user_id);

    if (error) throw error;

    return new Response(
      JSON.stringify({
        success: true,
        data: {
          message: 'Фандинг бот остановлен',
          status: 'ОТКЛЮЧЕН'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        error: `Ошибка остановки бота: ${error.message}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}