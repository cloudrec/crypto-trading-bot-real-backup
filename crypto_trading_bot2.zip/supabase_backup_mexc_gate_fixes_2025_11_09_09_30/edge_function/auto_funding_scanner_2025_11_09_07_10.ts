import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('🔍 AUTO FUNDING SCAN: Starting automatic funding scan');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем всех пользователей с включенным фандинг ботом
    const { data: activeUsers, error: usersError } = await supabase
      .from('funding_bot_settings_2025_11_09_06_55')
      .select('*')
      .eq('enabled', true);

    if (usersError) {
      console.error('🔍 AUTO FUNDING SCAN: Error getting users:', usersError);
      return new Response(
        JSON.stringify({ success: false, error: usersError.message }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🔍 AUTO FUNDING SCAN: Found', activeUsers?.length || 0, 'active users');

    if (!activeUsers || activeUsers.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No active funding bot users found',
          scanned_users: 0
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const results = [];

    // Сканируем фандинги для каждого активного пользователя
    for (const user of activeUsers) {
      try {
        console.log('🔍 AUTO FUNDING SCAN: Processing user:', user.user_id);
        
        const scanResult = await scanFundingForUser(user);
        results.push({
          user_id: user.user_id,
          ...scanResult
        });

        // Отправляем Telegram уведомления если есть возможности
        if (scanResult.opportunities && scanResult.opportunities.length > 0 && user.telegram_notifications) {
          await sendTelegramNotification(user, scanResult.opportunities);
        }

      } catch (error) {
        console.error('🔍 AUTO FUNDING SCAN: Error processing user:', user.user_id, error);
        results.push({
          user_id: user.user_id,
          error: error.message
        });
      }
    }

    console.log('🔍 AUTO FUNDING SCAN: Completed scan for', results.length, 'users');

    return new Response(
      JSON.stringify({
        success: true,
        scan_time: new Date().toISOString(),
        scanned_users: results.length,
        results: results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ AUTO FUNDING SCAN Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Сканирование фандингов для конкретного пользователя
async function scanFundingForUser(userSettings: any) {
  console.log('🔍 FUNDING SCAN: Scanning for user with min rate:', userSettings.min_funding_rate);
  
  const allOpportunities = [];
  
  // Сканируем каждую биржу из настроек пользователя
  for (const exchange of userSettings.exchanges) {
    try {
      console.log('🔍 FUNDING SCAN: Scanning', exchange);
      
      let opportunities = [];
      
      if (exchange === 'binance') {
        opportunities = await scanBinanceFunding(userSettings.min_funding_rate);
      } else if (exchange === 'bybit') {
        opportunities = await scanBybitFunding(userSettings.min_funding_rate);
      } else if (exchange === 'gate') {
        opportunities = await scanGateFunding(userSettings.min_funding_rate);
      }
      
      // Добавляем информацию о бирже к каждой возможности
      opportunities.forEach(opp => {
        opp.exchange = exchange.toUpperCase();
        allOpportunities.push(opp);
      });
      
      console.log('🔍 FUNDING SCAN:', exchange, 'found', opportunities.length, 'opportunities');
      
    } catch (error) {
      console.error('🔍 FUNDING SCAN: Error scanning', exchange, ':', error);
    }
  }

  // Сортируем по абсолютному значению фандинга (от большего к меньшему)
  allOpportunities.sort((a, b) => Math.abs(parseFloat(b.funding_rate)) - Math.abs(parseFloat(a.funding_rate)));

  return {
    opportunities: allOpportunities.slice(0, 10), // Топ 10 возможностей
    total_found: allOpportunities.length,
    min_funding_rate: userSettings.min_funding_rate,
    exchanges_scanned: userSettings.exchanges
  };
}

// Сканирование Binance
async function scanBinanceFunding(minRate: number) {
  try {
    const response = await fetch('https://fapi.binance.com/fapi/v1/premiumIndex');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.lastFundingRate) * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.lastFundingRate) * 100).toFixed(3),
        next_funding_time: item.nextFundingTime,
        mark_price: parseFloat(item.markPrice),
        exchange: 'BINANCE'
      }));
  } catch (error) {
    console.error('Error scanning Binance funding:', error);
    return [];
  }
}

// Сканирование Bybit
async function scanBybitFunding(minRate: number) {
  try {
    const response = await fetch('https://api.bybit.com/v5/market/tickers?category=linear');
    const data = await response.json();
    
    if (data.retCode !== 0) return [];
    
    return data.result.list
      .filter((item: any) => {
        const rate = parseFloat(item.fundingRate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.fundingRate || '0') * 100).toFixed(3),
        mark_price: parseFloat(item.markPrice || '0'),
        exchange: 'BYBIT'
      }));
  } catch (error) {
    console.error('Error scanning Bybit funding:', error);
    return [];
  }
}

// Сканирование Gate.io
async function scanGateFunding(minRate: number) {
  try {
    const response = await fetch('https://api.gateio.ws/api/v4/futures/usdt/tickers');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.funding_rate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.contract,
        funding_rate: (parseFloat(item.funding_rate || '0') * 100).toFixed(3),
        mark_price: parseFloat(item.mark_price || '0'),
        exchange: 'GATE'
      }));
  } catch (error) {
    console.error('Error scanning Gate funding:', error);
    return [];
  }
}

// Отправка Telegram уведомления
async function sendTelegramNotification(userSettings: any, opportunities: any[]) {
  if (!userSettings.telegram_chat_id) {
    console.log('🔍 TELEGRAM: No chat ID for user:', userSettings.user_id);
    return;
  }

  try {
    const telegramToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    if (!telegramToken) {
      console.log('🔍 TELEGRAM: No bot token configured');
      return;
    }

    // Формируем сообщение
    let message = `🔍 *ФАНДИНГ ВОЗМОЖНОСТИ* 🔍\n\n`;
    message += `Найдено ${opportunities.length} возможностей:\n\n`;

    opportunities.slice(0, 5).forEach((opp, index) => {
      const rate = parseFloat(opp.funding_rate);
      const emoji = rate > 0 ? '📈' : '📉';
      const direction = rate > 0 ? 'SHORT' : 'LONG';
      
      message += `${index + 1}. ${emoji} *${opp.symbol}* (${opp.exchange})\n`;
      message += `   Фандинг: *${opp.funding_rate}%*\n`;
      message += `   Направление: *${direction}*\n`;
      message += `   Цена: $${opp.mark_price}\n\n`;
    });

    message += `⏰ Время сканирования: ${new Date().toLocaleString('ru-RU')}\n`;
    message += `⚙️ Мин. фандинг: ${userSettings.min_funding_rate}%`;

    const telegramUrl = `https://api.telegram.org/bot${telegramToken}/sendMessage`;
    
    const response = await fetch(telegramUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: userSettings.telegram_chat_id,
        text: message,
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })
    });

    const result = await response.json();
    
    if (response.ok) {
      console.log('🔍 TELEGRAM: Message sent successfully to:', userSettings.telegram_chat_id);
    } else {
      console.error('🔍 TELEGRAM: Error sending message:', result);
    }

  } catch (error) {
    console.error('🔍 TELEGRAM: Error:', error);
  }
}