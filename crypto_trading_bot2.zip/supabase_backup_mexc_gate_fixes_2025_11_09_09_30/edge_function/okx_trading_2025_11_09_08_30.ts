import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, user_id } = await req.json();
    console.log('🟠 OKX: Starting action:', action, 'for user:', user_id);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем API ключи OKX
    const { data: apiKeys, error: keysError } = await supabase
      .from('api_keys_dev')
      .select('*')
      .eq('user_id', user_id)
      .eq('exchange', 'okx')
      .single();

    if (keysError || !apiKeys) {
      console.error('🟠 OKX: No API keys found:', keysError);
      return new Response(
        JSON.stringify({ success: false, error: 'OKX API keys not found' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🟠 OKX: API keys found');

    const apiKey = apiKeys.api_key;
    const apiSecret = apiKeys.api_secret;
    const passphrase = apiKeys.passphrase; // OKX требует passphrase

    if (action === 'get_balance') {
      return await handleOKXBalance(apiKey, apiSecret, passphrase);
    } else if (action === 'place_order_with_tp_sl') {
      return await handleOKXOrder(apiKey, apiSecret, passphrase, user_id, supabase);
    } else if (action === 'get_positions') {
      return await handleOKXPositions(apiKey, apiSecret, passphrase);
    } else if (action === 'close_positions') {
      return await handleOKXClosePositions(apiKey, apiSecret, passphrase);
    } else if (action === 'cancel_orders') {
      return await handleOKXCancelOrders(apiKey, apiSecret, passphrase);
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Unknown action' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ OKX Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Создание подписи для OKX API
function createOKXSignature(apiSecret: string, timestamp: string, method: string, requestPath: string, body: string = '') {
  const message = timestamp + method + requestPath + body;
  
  const encoder = new TextEncoder();
  const keyData = encoder.encode(apiSecret);
  const messageData = encoder.encode(message);
  
  return crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  ).then(key => {
    return crypto.subtle.sign('HMAC', key, messageData);
  }).then(signature => {
    const base64 = btoa(String.fromCharCode(...new Uint8Array(signature)));
    console.log('🟠 OKX: Signature created');
    return base64;
  });
}

// Получение баланса
async function handleOKXBalance(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    console.log('🟠 OKX: Getting balance...');
    
    const timestamp = new Date().toISOString();
    const method = 'GET';
    const requestPath = '/api/v5/account/balance';
    
    const signature = await createOKXSignature(apiSecret, timestamp, method, requestPath);
    
    const url = `https://www.okx.com${requestPath}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'OK-ACCESS-KEY': apiKey,
        'OK-ACCESS-SIGN': signature,
        'OK-ACCESS-TIMESTAMP': timestamp,
        'OK-ACCESS-PASSPHRASE': passphrase,
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    console.log('🟠 OKX: Balance response:', JSON.stringify(data, null, 2));

    if (data.code !== '0') {
      throw new Error(`OKX API error: ${data.msg} (Code: ${data.code})`);
    }

    // Ищем USDT баланс
    let usdtBalance = 0;
    if (data.data && data.data[0] && data.data[0].details) {
      const usdtDetail = data.data[0].details.find((detail: any) => detail.ccy === 'USDT');
      if (usdtDetail) {
        usdtBalance = parseFloat(usdtDetail.availBal || '0');
      }
    }

    console.log('🟠 OKX: USDT Balance:', usdtBalance);

    return new Response(
      JSON.stringify({
        success: true,
        balance: usdtBalance,
        status: 'OKX LIVE ✅',
        debug: {
          function: 'okx_trading_2025_11_09_08_30',
          api_version: 'V5'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🟠 OKX: Balance error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `OKX balance error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Размещение ордера с TP/SL
async function handleOKXOrder(apiKey: string, apiSecret: string, passphrase: string, user_id: string, supabase: any) {
  try {
    console.log('🟠 OKX: Placing order...');

    // Получаем настройки пользователя
    const { data: settings } = await supabase
      .from('trading_settings_dev')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (!settings) {
      throw new Error('Trading settings not found');
    }

    // Проверяем баланс
    const balanceResponse = await handleOKXBalance(apiKey, apiSecret, passphrase);
    const balanceData = await balanceResponse.json();
    
    if (!balanceData.success) {
      throw new Error('Cannot get balance: ' + balanceData.error);
    }

    const balance = balanceData.balance;
    console.log('🟠 OKX: Available balance:', balance, 'USDT');

    if (balance < 10) {
      throw new Error(`Insufficient balance. Available: ${balance} USDT, Minimum required: 10 USDT`);
    }

    const symbol = `${settings.base_asset}-USDT-SWAP`; // OKX использует формат BTC-USDT-SWAP
    console.log('🟠 OKX: Trading symbol:', symbol);

    // Получаем текущую цену
    const tickerResponse = await fetch(`https://www.okx.com/api/v5/market/ticker?instId=${symbol}`);
    const tickerData = await tickerResponse.json();
    
    if (tickerData.code !== '0') {
      throw new Error(`Cannot get price for ${symbol}: ${tickerData.msg}`);
    }

    const currentPrice = parseFloat(tickerData.data[0].last);
    console.log('🟠 OKX: Current price for', symbol, ':', currentPrice);

    // Рассчитываем количество
    const orderValue = Math.min(settings.order_amount_usd || 10, balance * 0.05);
    const sz = Math.floor(orderValue / currentPrice * 100) / 100; // OKX размер в базовой валюте
    
    console.log('🟠 OKX: Order size:', sz);

    if (sz < 0.01) {
      throw new Error(`Order size ${sz} is below minimum 0.01`);
    }

    // Размещаем основной ордер
    const timestamp = new Date().toISOString();
    const method = 'POST';
    const requestPath = '/api/v5/trade/order';
    
    const orderData = {
      instId: symbol,
      tdMode: 'cross',
      side: 'buy',
      ordType: 'market',
      sz: sz.toString(),
      lever: (settings.leverage || 10).toString()
    };

    const body = JSON.stringify(orderData);
    const signature = await createOKXSignature(apiSecret, timestamp, method, requestPath, body);

    console.log('🟠 OKX: Placing order with data:', orderData);

    const response = await fetch(`https://www.okx.com${requestPath}`, {
      method: 'POST',
      headers: {
        'OK-ACCESS-KEY': apiKey,
        'OK-ACCESS-SIGN': signature,
        'OK-ACCESS-TIMESTAMP': timestamp,
        'OK-ACCESS-PASSPHRASE': passphrase,
        'Content-Type': 'application/json'
      },
      body: body
    });

    const result = await response.json();
    console.log('🟠 OKX: Order response:', JSON.stringify(result, null, 2));

    if (result.code !== '0') {
      throw new Error(`OKX order error: ${result.msg} (Code: ${result.code})`);
    }

    // Рассчитываем TP и SL цены
    const tpPrice = (currentPrice * (1 + (settings.take_profit_percent || 2) / 100)).toFixed(2);
    const slPrice = (currentPrice * (1 - (settings.stop_loss_percent || 2) / 100)).toFixed(2);

    console.log('🟠 OKX: TP Price:', tpPrice, 'SL Price:', slPrice);

    return new Response(
      JSON.stringify({
        success: true,
        order_id: result.data[0].ordId,
        symbol: symbol,
        side: 'buy',
        size: sz,
        price: currentPrice,
        tp_price: tpPrice,
        sl_price: slPrice,
        status: 'OKX ORDER PLACED ✅'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🟠 OKX: Order error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `OKX order error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Получение позиций
async function handleOKXPositions(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    const timestamp = new Date().toISOString();
    const method = 'GET';
    const requestPath = '/api/v5/account/positions';
    
    const signature = await createOKXSignature(apiSecret, timestamp, method, requestPath);
    
    const response = await fetch(`https://www.okx.com${requestPath}`, {
      method: 'GET',
      headers: {
        'OK-ACCESS-KEY': apiKey,
        'OK-ACCESS-SIGN': signature,
        'OK-ACCESS-TIMESTAMP': timestamp,
        'OK-ACCESS-PASSPHRASE': passphrase,
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    
    if (data.code !== '0') {
      throw new Error(`OKX API error: ${data.msg}`);
    }

    const positions = data.data
      .filter((pos: any) => parseFloat(pos.pos) !== 0)
      .map((pos: any) => ({
        symbol: pos.instId,
        side: parseFloat(pos.pos) > 0 ? 'Buy' : 'Sell',
        size: Math.abs(parseFloat(pos.pos)).toString(),
        entry_price: pos.avgPx,
        mark_price: pos.markPx,
        pnl: pos.upl,
        percentage: pos.uplRatio ? (parseFloat(pos.uplRatio) * 100).toFixed(2) : '0'
      }));

    return new Response(
      JSON.stringify({ success: true, positions }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Закрытие позиций
async function handleOKXClosePositions(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    // Сначала получаем открытые позиции
    const positionsResponse = await handleOKXPositions(apiKey, apiSecret, passphrase);
    const positionsData = await positionsResponse.json();
    
    if (!positionsData.success || !positionsData.positions.length) {
      return new Response(
        JSON.stringify({ success: true, closed_positions: 0, message: 'No positions to close' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let closedCount = 0;
    
    for (const position of positionsData.positions) {
      try {
        const timestamp = new Date().toISOString();
        const method = 'POST';
        const requestPath = '/api/v5/trade/close-position';
        
        const orderData = {
          instId: position.symbol,
          mgnMode: 'cross'
        };

        const body = JSON.stringify(orderData);
        const signature = await createOKXSignature(apiSecret, timestamp, method, requestPath, body);

        const response = await fetch(`https://www.okx.com${requestPath}`, {
          method: 'POST',
          headers: {
            'OK-ACCESS-KEY': apiKey,
            'OK-ACCESS-SIGN': signature,
            'OK-ACCESS-TIMESTAMP': timestamp,
            'OK-ACCESS-PASSPHRASE': passphrase,
            'Content-Type': 'application/json'
          },
          body: body
        });

        const result = await response.json();
        
        if (result.code === '0') {
          closedCount++;
        }
        
      } catch (error) {
        console.error('Error closing OKX position:', position.symbol, error);
      }
    }

    return new Response(
      JSON.stringify({ success: true, closed_positions: closedCount }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Отмена ордеров
async function handleOKXCancelOrders(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    const timestamp = new Date().toISOString();
    const method = 'POST';
    const requestPath = '/api/v5/trade/cancel-all-after';
    
    const orderData = {
      timeOut: '0' // Отменить все ордера немедленно
    };

    const body = JSON.stringify(orderData);
    const signature = await createOKXSignature(apiSecret, timestamp, method, requestPath, body);

    const response = await fetch(`https://www.okx.com${requestPath}`, {
      method: 'POST',
      headers: {
        'OK-ACCESS-KEY': apiKey,
        'OK-ACCESS-SIGN': signature,
        'OK-ACCESS-TIMESTAMP': timestamp,
        'OK-ACCESS-PASSPHRASE': passphrase,
        'Content-Type': 'application/json'
      },
      body: body
    });

    const result = await response.json();
    
    if (result.code !== '0') {
      throw new Error(`OKX API error: ${result.msg}`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        cancelled_orders: 'all',
        message: 'All orders cancelled'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}