import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, user_id } = await req.json();
    console.log('🔴 MEXC: Starting action:', action, 'for user:', user_id);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем API ключи MEXC
    const { data: apiKeys, error: keysError } = await supabase
      .from('api_keys_dev')
      .select('*')
      .eq('user_id', user_id)
      .eq('exchange', 'mexc')
      .single();

    if (keysError || !apiKeys) {
      console.error('🔴 MEXC: No API keys found:', keysError);
      return new Response(
        JSON.stringify({ success: false, error: 'MEXC API keys not found' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🔴 MEXC: API keys found');

    const apiKey = apiKeys.api_key;
    const apiSecret = apiKeys.api_secret;

    if (action === 'get_balance') {
      return await handleMEXCBalance(apiKey, apiSecret);
    } else if (action === 'place_order_with_tp_sl') {
      return await handleMEXCOrder(apiKey, apiSecret, user_id, supabase);
    } else if (action === 'get_positions') {
      return await handleMEXCPositions(apiKey, apiSecret);
    } else if (action === 'close_positions') {
      return await handleMEXCClosePositions(apiKey, apiSecret);
    } else if (action === 'cancel_orders') {
      return await handleMEXCCancelOrders(apiKey, apiSecret);
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Unknown action' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ MEXC Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Создание подписи для MEXC API
function createMEXCSignature(apiSecret: string, queryString: string) {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(apiSecret);
  const messageData = encoder.encode(queryString);
  
  return crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  ).then(key => {
    return crypto.subtle.sign('HMAC', key, messageData);
  }).then(signature => {
    const hex = Array.from(new Uint8Array(signature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    console.log('🔴 MEXC: Signature created');
    return hex;
  });
}

// Получение баланса
async function handleMEXCBalance(apiKey: string, apiSecret: string) {
  try {
    console.log('🔴 MEXC: Getting balance...');
    
    const timestamp = Date.now();
    const queryString = `timestamp=${timestamp}`;
    
    const signature = await createMEXCSignature(apiSecret, queryString);
    
    const url = `https://contract.mexc.com/api/v1/private/account/assets?${queryString}&signature=${signature}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'ApiKey': apiKey,
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    console.log('🔴 MEXC: Balance response:', JSON.stringify(data, null, 2));

    if (data.code !== 0) {
      throw new Error(`MEXC API error: ${data.msg} (Code: ${data.code})`);
    }

    // Ищем USDT баланс
    let usdtBalance = 0;
    if (data.data && Array.isArray(data.data)) {
      const usdtAsset = data.data.find((asset: any) => asset.currency === 'USDT');
      if (usdtAsset) {
        usdtBalance = parseFloat(usdtAsset.availableBalance || '0');
      }
    }

    console.log('🔴 MEXC: USDT Balance:', usdtBalance);

    return new Response(
      JSON.stringify({
        success: true,
        balance: usdtBalance,
        status: 'MEXC LIVE ✅',
        debug: {
          function: 'mexc_trading_2025_11_09_08_30',
          api_version: 'V1'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🔴 MEXC: Balance error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `MEXC balance error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Размещение ордера с TP/SL
async function handleMEXCOrder(apiKey: string, apiSecret: string, user_id: string, supabase: any) {
  try {
    console.log('🔴 MEXC: Placing order...');

    // Получаем настройки пользователя
    const { data: settings } = await supabase
      .from('trading_settings_dev')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (!settings) {
      throw new Error('Trading settings not found');
    }

    // Проверяем баланс
    const balanceResponse = await handleMEXCBalance(apiKey, apiSecret);
    const balanceData = await balanceResponse.json();
    
    if (!balanceData.success) {
      throw new Error('Cannot get balance: ' + balanceData.error);
    }

    const balance = balanceData.balance;
    console.log('🔴 MEXC: Available balance:', balance, 'USDT');

    if (balance < 10) {
      throw new Error(`Insufficient balance. Available: ${balance} USDT, Minimum required: 10 USDT`);
    }

    const symbol = `${settings.base_asset}_USDT`; // MEXC использует формат BTC_USDT
    console.log('🔴 MEXC: Trading symbol:', symbol);

    // Получаем текущую цену
    const tickerResponse = await fetch(`https://contract.mexc.com/api/v1/contract/ticker/${symbol}`);
    const tickerData = await tickerResponse.json();
    
    if (tickerData.code !== 0) {
      throw new Error(`Cannot get price for ${symbol}: ${tickerData.msg}`);
    }

    const currentPrice = parseFloat(tickerData.data.lastPrice);
    console.log('🔴 MEXC: Current price for', symbol, ':', currentPrice);

    // Рассчитываем количество
    const orderValue = Math.min(settings.order_amount_usd || 10, balance * 0.05);
    const vol = Math.floor(orderValue); // MEXC размер в USDT
    
    console.log('🔴 MEXC: Order volume:', vol, 'USDT');

    if (vol < 5) {
      throw new Error(`Order volume ${vol} is below minimum 5 USDT`);
    }

    // Размещаем основной ордер
    const timestamp = Date.now();
    const orderParams = {
      symbol: symbol,
      side: 1, // 1 = buy, 2 = sell
      type: 5, // 5 = market order
      vol: vol,
      leverage: settings.leverage || 10,
      timestamp: timestamp
    };

    const queryString = Object.entries(orderParams)
      .map(([key, value]) => `${key}=${value}`)
      .join('&');

    const signature = await createMEXCSignature(apiSecret, queryString);

    console.log('🔴 MEXC: Placing order with params:', orderParams);

    const response = await fetch(`https://contract.mexc.com/api/v1/private/order/submit?${queryString}&signature=${signature}`, {
      method: 'POST',
      headers: {
        'ApiKey': apiKey,
        'Content-Type': 'application/json'
      }
    });

    const result = await response.json();
    console.log('🔴 MEXC: Order response:', JSON.stringify(result, null, 2));

    if (result.code !== 0) {
      throw new Error(`MEXC order error: ${result.msg} (Code: ${result.code})`);
    }

    // Рассчитываем TP и SL цены
    const tpPrice = (currentPrice * (1 + (settings.take_profit_percent || 2) / 100)).toFixed(2);
    const slPrice = (currentPrice * (1 - (settings.stop_loss_percent || 2) / 100)).toFixed(2);

    console.log('🔴 MEXC: TP Price:', tpPrice, 'SL Price:', slPrice);

    return new Response(
      JSON.stringify({
        success: true,
        order_id: result.data,
        symbol: symbol,
        side: 'buy',
        volume: vol,
        price: currentPrice,
        tp_price: tpPrice,
        sl_price: slPrice,
        status: 'MEXC ORDER PLACED ✅'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🔴 MEXC: Order error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `MEXC order error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Получение позиций
async function handleMEXCPositions(apiKey: string, apiSecret: string) {
  try {
    const timestamp = Date.now();
    const queryString = `timestamp=${timestamp}`;
    
    const signature = await createMEXCSignature(apiSecret, queryString);
    
    const response = await fetch(`https://contract.mexc.com/api/v1/private/position/list/all?${queryString}&signature=${signature}`, {
      method: 'GET',
      headers: {
        'ApiKey': apiKey,
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    
    if (data.code !== 0) {
      throw new Error(`MEXC API error: ${data.msg}`);
    }

    const positions = data.data
      .filter((pos: any) => parseFloat(pos.holdVol) !== 0)
      .map((pos: any) => ({
        symbol: pos.symbol,
        side: pos.positionType === 1 ? 'Buy' : 'Sell',
        size: pos.holdVol,
        entry_price: pos.holdAvgPrice,
        mark_price: pos.markPrice,
        pnl: pos.unrealisedPnl,
        percentage: pos.unrealisedPnlPcnt ? (parseFloat(pos.unrealisedPnlPcnt) * 100).toFixed(2) : '0'
      }));

    return new Response(
      JSON.stringify({ success: true, positions }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Закрытие позиций
async function handleMEXCClosePositions(apiKey: string, apiSecret: string) {
  try {
    // Сначала получаем открытые позиции
    const positionsResponse = await handleMEXCPositions(apiKey, apiSecret);
    const positionsData = await positionsResponse.json();
    
    if (!positionsData.success || !positionsData.positions.length) {
      return new Response(
        JSON.stringify({ success: true, closed_positions: 0, message: 'No positions to close' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let closedCount = 0;
    
    for (const position of positionsData.positions) {
      try {
        const timestamp = Date.now();
        const closeParams = {
          symbol: position.symbol,
          side: position.side === 'Buy' ? 2 : 1, // Противоположная сторона
          type: 5, // Market order
          vol: position.size,
          timestamp: timestamp
        };

        const queryString = Object.entries(closeParams)
          .map(([key, value]) => `${key}=${value}`)
          .join('&');

        const signature = await createMEXCSignature(apiSecret, queryString);

        const response = await fetch(`https://contract.mexc.com/api/v1/private/order/submit?${queryString}&signature=${signature}`, {
          method: 'POST',
          headers: {
            'ApiKey': apiKey,
            'Content-Type': 'application/json'
          }
        });

        const result = await response.json();
        
        if (result.code === 0) {
          closedCount++;
        }
        
      } catch (error) {
        console.error('Error closing MEXC position:', position.symbol, error);
      }
    }

    return new Response(
      JSON.stringify({ success: true, closed_positions: closedCount }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Отмена ордеров
async function handleMEXCCancelOrders(apiKey: string, apiSecret: string) {
  try {
    const timestamp = Date.now();
    const queryString = `timestamp=${timestamp}`;
    
    const signature = await createMEXCSignature(apiSecret, queryString);

    const response = await fetch(`https://contract.mexc.com/api/v1/private/order/cancel/all?${queryString}&signature=${signature}`, {
      method: 'POST',
      headers: {
        'ApiKey': apiKey,
        'Content-Type': 'application/json'
      }
    });

    const result = await response.json();
    
    if (result.code !== 0) {
      throw new Error(`MEXC API error: ${result.msg}`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        cancelled_orders: 'all',
        message: 'All orders cancelled'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}