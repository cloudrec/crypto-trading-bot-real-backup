# 🌐 Настройка домена fundbot.win

## 🚀 Актуальные настройки для Cloudflare

### **Текущий рабочий адрес бота:**
`zvxhybhst3.skywork.website`

### **Настройка DNS записи:**

1. **Войдите в Cloudflare Dashboard**
2. **Выберите домен:** fundbot.win
3. **DNS → Records → Редактировать CNAME**

```
Type: CNAME
Name: @ (для основного домена)
Target: zvxhybhst3.skywork.website
Proxy status: Proxied (🟠)
TTL: Auto
```

### **SSL/TLS настройки:**
```
Encryption mode: Full (strict)
Always Use HTTPS: ON
```

### **Дополнительные настройки:**

#### **Page Rules (опционально):**
```
URL: www.fundbot.win/*
Setting: Forwarding URL (301)
Destination: https://fundbot.win/$1
```

#### **Caching:**
```
Caching Level: Standard
Browser Cache TTL: 4 hours
```

## 🧪 Проверка работы

### **После изменений подождите:**
- **DNS обновление:** 5-15 минут
- **SSL активация:** 5-10 минут
- **Полное распространение:** до 48 часов

### **Команды для проверки:**
```bash
# Проверка DNS
nslookup fundbot.win

# Проверка HTTP ответа
curl -I https://fundbot.win

# Проверка SSL
openssl s_client -connect fundbot.win:443
```

## 🚨 Возможные ошибки и решения

### **500 Internal Server Error**
**Причина:** Неправильный Target в CNAME
**Решение:** Обновить Target на `zvxhybhst3.skywork.website`

### **SSL Certificate Error**
**Причина:** Неправильный SSL режим
**Решение:** Установить "Full (strict)" режим

### **Too Many Redirects**
**Причина:** Конфликт HTTPS настроек
**Решение:** Временно отключить "Always Use HTTPS"

### **DNS_PROBE_FINISHED_NXDOMAIN**
**Причина:** DNS не обновился
**Решение:** Подождать до 48 часов

## ✅ Результат

После правильной настройки:
- **https://fundbot.win** → Торговый бот
- **SSL сертификат** работает
- **Быстрая загрузка** через Cloudflare CDN
- **Защита от DDoS** активна

---

**Резервный адрес:** https://zvxhybhst3.skywork.website
**Целевой адрес:** https://fundbot.win