# 🤖 Пошаговая настройка автоматического обновления домена

## 📋 Что вам нужно сделать:

### **Шаг 1: Получите API Token от Cloudflare**

1. **Перейдите:** https://dash.cloudflare.com/profile/api-tokens
2. **Нажмите:** "Create Token"
3. **Выберите:** "Custom token"
4. **Заполните форму:**

```
Token name: fundbot-updater

Permissions:
✅ Zone : Zone : Read
✅ Zone : DNS : Edit

Zone Resources:
✅ Include : Specific zone : fundbot.win

Client IP Address Filtering: (оставьте пустым)
TTL: (оставьте по умолчанию)
```

5. **Нажмите:** "Continue to summary" → "Create Token"
6. **СКОПИРУЙТЕ TOKEN** (показывается только один раз!)

### **Шаг 2: Получите Zone ID**

1. **Cloudflare Dashboard** → выберите домен `fundbot.win`
2. **В правой панели** найдите "Zone ID"
3. **Скопируйте Zone ID** (выглядит как: `1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p`)

### **Шаг 3: Настройте скрипт**

Отредактируйте файл `crypto_trading_bot/update_domain.sh`:

```bash
# Найдите эти строки и замените на ваши значения:
CLOUDFLARE_API_TOKEN="ваш_api_token_здесь"
ZONE_ID="ваш_zone_id_здесь"
```

**Пример:**
```bash
CLOUDFLARE_API_TOKEN="1234567890abcdef_ваш_реальный_токен"
ZONE_ID="1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p"
```

### **Шаг 4: Запустите скрипт**

```bash
cd crypto_trading_bot
./update_domain.sh
```

**Успешный результат:**
```
🎉 CNAME запись успешно обновлена!
🌐 fundbot.win теперь указывает на 8bmi9c3cut.skywork.website
⏱️ Изменения вступят в силу через 5-15 минут
🔗 Проверьте: https://fundbot.win
```

## 🚀 **После настройки:**

### **Автоматическое использование:**
После каждой публикации проекта я буду автоматически запускать скрипт для обновления домена.

### **Ручное использование:**
Если нужно обновить домен вручную:
```bash
cd crypto_trading_bot
./update_domain.sh
```

## 🎯 **Результат:**

✅ **fundbot.win** всегда будет указывать на актуальный адрес
✅ **Автоматическое обновление** после каждой сборки
✅ **Стабильный домен** для ваших пользователей
✅ **Никаких ручных изменений** в Cloudflare

## 🆘 **Если что-то не работает:**

### **Ошибка "Invalid API Token":**
- Проверьте правильность API Token
- Убедитесь что токен имеет права Zone:Read и DNS:Edit
- Проверьте что токен создан для зоны fundbot.win

### **Ошибка "Zone not found":**
- Проверьте правильность Zone ID
- Убедитесь что домен fundbot.win добавлен в Cloudflare

### **Ошибка "Record not found":**
- Создайте CNAME запись вручную в Cloudflare:
  ```
  Type: CNAME
  Name: @
  Target: 8bmi9c3cut.skywork.website
  Proxy: ON (🟠)
  ```

---

## 📞 **Нужна помощь?**

Пришлите мне:
1. **API Token** (я помогу настроить)
2. **Zone ID** 
3. **Скриншот ошибки** (если есть)

И я настрою автоматическое обновление за вас!