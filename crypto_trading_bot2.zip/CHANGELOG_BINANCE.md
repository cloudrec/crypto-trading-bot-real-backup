# CHANGELOG - BINANCE (ОБНОВЛЕНО)

## v15 (2025-11-09 15:45) - КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ
### ✅ ИСПРАВЛЕНО
- **КРИТИЧНО:** Исправлена проблема SHORT → LONG
- Добавлен параметр `order_type` в функцию `handleBinanceOrder`
- Правильное определение направления:
  - LONG: `side: 'BUY'` для входа, `side: 'SELL'` для TP/SL
  - SHORT: `side: 'SELL'` для входа, `side: 'BUY'` для TP/SL
- Правильный расчет TP/SL цен для SHORT позиций

### 🔧 Edge Function
- `binance_fixed_long_short_2025_11_09_15_45`
- Поддерживает: LONG/SHORT с правильными направлениями
- Статус: ✅ ИСПРАВЛЕНО

### 📊 Логика направлений
```javascript
const isLong = orderType === 'LONG';
const mainSide = isLong ? 'BUY' : 'SELL';
const closeSide = isLong ? 'SELL' : 'BUY';

// TP/SL цены
if (isLong) {
  tpPrice = currentPrice * 1.02; // +2%
  slPrice = currentPrice * 0.98; // -2%
} else {
  tpPrice = currentPrice * 0.98; // -2% для SHORT
  slPrice = currentPrice * 1.02; // +2% для SHORT
}
```

## v14 (2025-11-09 15:30)
### ✅ Исправления
- Улучшена обработка ответов API (убраны ложные ошибки)
- Добавлены LONG/SHORT кнопки в интерфейс

### ❌ Известные проблемы (ИСПРАВЛЕНО в v15)
- SHORT кнопка ставила LONG позицию

## Предыдущие версии
- v13: Проверка статуса ордера
- v12: Поддержка LONG/SHORT (с ошибкой направления)
- v1-v11: Эволюция TP/SL подходов