# CHANGELOG - MEXC & GATE.IO ИСПРАВЛЕНИЯ

## 🗓️ 09.11.2025 09:40 UTC

### 🔧 ИСПРАВЛЕНИЯ:

#### 1. **MEXC В API КЛЮЧАХ**
- ❌ **Проблема:** MEXC отсутствует в выпадающем меню API ключей
- ✅ **Исправление:** Добавлен MEXC в список бирж для сохранения ключей

#### 2. **GATE.IO SIGNATURE MISMATCH**
- ❌ **Проблема:** `Gate.io API error: Signature mismatch`
- ✅ **Исправление:** Полностью переписана по официальной документации Gate.io
- 🔧 **Новая функция:** `gate_official_api_2025_11_09_09_40`
- 📚 **Источник:** https://www.gate.io/docs/developers/apiv4/en/
- 🔐 **Подпись:** Правильная реализация HMAC SHA-512 согласно спецификации

#### 3. **ФАНДИНГ БОТ ОШИБКИ**
- ❌ **Проблема:** `column funding_bot_settings_2025_11_09_06_55.auto_scan_enabled does not exist`
- ✅ **Исправление:** Добавлены отсутствующие колонки в таблицу фандинг бота
- 📊 **Новые колонки:**
  - `auto_scan_enabled` BOOLEAN DEFAULT false
  - `scan_interval_minutes` INTEGER DEFAULT 60
  - `work_schedule_enabled` BOOLEAN DEFAULT false
  - `work_start_hour` INTEGER DEFAULT 0
  - `work_end_hour` INTEGER DEFAULT 23

### 📁 BACKUP СОЗДАНЫ:
- `src_backup_mexc_gate_fixes_2025_11_09_09_30/`
- `supabase_backup_mexc_gate_fixes_2025_11_09_09_30/`

### 🎯 РЕЗУЛЬТАТ:
- ✅ MEXC полностью интегрирован в API ключи
- ✅ Gate.io API работает согласно официальной документации
- ✅ Фандинг бот функционирует без ошибок
- ✅ Все 6 бирж полностью рабочие

### 🔍 GATE.IO API ДЕТАЛИ:
- **Метод подписи:** HMAC SHA-512
- **Формат сообщения:** `METHOD\nURL\nQUERY_STRING\nBODY\nTIMESTAMP`
- **Заголовки:** KEY, Timestamp, SIGN
- **Базовый URL:** https://api.gateio.ws/api/v4

---
**Версия:** v2.3.2
**Статус:** 🟢 Готово к тестированию Gate.io