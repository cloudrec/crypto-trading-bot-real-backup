import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, user_id } = await req.json();
    console.log('🔵 BYBIT FIXED: Starting action:', action, 'for user:', user_id);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем API ключи Bybit
    const { data: apiKeys, error: keysError } = await supabase
      .from('api_keys_dev')
      .select('*')
      .eq('user_id', user_id)
      .eq('exchange', 'bybit')
      .single();

    if (keysError || !apiKeys) {
      console.error('🔵 BYBIT FIXED: No API keys found:', keysError);
      return new Response(
        JSON.stringify({ success: false, error: 'Bybit API keys not found' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🔵 BYBIT FIXED: API keys found');
    console.log('🔵 BYBIT FIXED: API Key length:', apiKeys.api_key?.length || 0);
    console.log('🔵 BYBIT FIXED: Secret length:', apiKeys.api_secret?.length || 0);

    const apiKey = apiKeys.api_key;
    const apiSecret = apiKeys.api_secret;

    if (action === 'get_balance') {
      return await handleBybitBalance(apiKey, apiSecret);
    } else if (action === 'place_order_with_tp_sl') {
      return await handleBybitOrder(apiKey, apiSecret, user_id, supabase);
    } else if (action === 'get_positions') {
      return await handleBybitPositions(apiKey, apiSecret);
    } else if (action === 'close_positions') {
      return await handleBybitClosePositions(apiKey, apiSecret);
    } else if (action === 'cancel_orders') {
      return await handleBybitCancelOrders(apiKey, apiSecret);
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Unknown action' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ BYBIT FIXED Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Создание подписи для Bybit V5 API
function createBybitV5Signature(apiKey: string, apiSecret: string, timestamp: string, queryString: string = '', body: string = '') {
  console.log('🔵 BYBIT FIXED: Creating signature for timestamp:', timestamp);
  
  const recvWindow = '5000';
  let paramString = '';
  
  if (queryString) {
    // GET запрос
    paramString = timestamp + apiKey + recvWindow + queryString;
  } else {
    // POST запрос
    paramString = timestamp + apiKey + recvWindow + body;
  }
  
  console.log('🔵 BYBIT FIXED: Param string length:', paramString.length);
  
  const encoder = new TextEncoder();
  const keyData = encoder.encode(apiSecret);
  const messageData = encoder.encode(paramString);
  
  return crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  ).then(key => {
    return crypto.subtle.sign('HMAC', key, messageData);
  }).then(signature => {
    const hex = Array.from(new Uint8Array(signature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    console.log('🔵 BYBIT FIXED: Signature created, length:', hex.length);
    return hex;
  });
}

// Получение баланса
async function handleBybitBalance(apiKey: string, apiSecret: string) {
  try {
    console.log('🔵 BYBIT FIXED: Getting balance...');
    
    const timestamp = Date.now().toString();
    const queryString = 'accountType=UNIFIED'; // ИСПРАВЛЕНО: используем UNIFIED вместо category
    
    const signature = await createBybitV5Signature(apiKey, apiSecret, timestamp, queryString);
    
    const url = `https://api.bybit.com/v5/account/wallet-balance?${queryString}`;
    console.log('🔵 BYBIT FIXED: Making request to:', url);
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-BAPI-API-KEY': apiKey,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': '5000',
        'Content-Type': 'application/json'
      }
    });

    console.log('🔵 BYBIT FIXED: Response status:', response.status);
    const data = await response.json();
    console.log('🔵 BYBIT FIXED: Response data:', JSON.stringify(data, null, 2));

    if (data.retCode !== 0) {
      throw new Error(`Bybit API error: ${data.retMsg} (Code: ${data.retCode})`);
    }

    // Ищем USDT баланс
    let usdtBalance = 0;
    if (data.result?.list?.[0]?.coin) {
      const usdtCoin = data.result.list[0].coin.find((coin: any) => coin.coin === 'USDT');
      if (usdtCoin) {
        usdtBalance = parseFloat(usdtCoin.walletBalance || '0');
      }
    }

    console.log('🔵 BYBIT FIXED: USDT Balance:', usdtBalance);

    return new Response(
      JSON.stringify({
        success: true,
        balance: usdtBalance,
        status: 'BYBIT LIVE ✅',
        debug: {
          function: 'bybit_fixed_working_2025_11_09_07_15',
          api_version: 'V5',
          account_type: 'UNIFIED'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🔵 BYBIT FIXED: Balance error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `Bybit balance error: ${error.message}`,
        debug: {
          function: 'bybit_fixed_working_2025_11_09_07_15',
          api_version: 'V5'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Размещение ордера с TP/SL
async function handleBybitOrder(apiKey: string, apiSecret: string, user_id: string, supabase: any) {
  try {
    console.log('🔵 BYBIT FIXED: Placing order...');

    // Получаем настройки пользователя
    const { data: settings } = await supabase
      .from('trading_settings_dev')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (!settings) {
      throw new Error('Trading settings not found');
    }

    // Сначала проверяем баланс
    const balanceResponse = await handleBybitBalance(apiKey, apiSecret);
    const balanceData = await balanceResponse.json();
    
    if (!balanceData.success) {
      throw new Error('Cannot get balance: ' + balanceData.error);
    }

    const balance = balanceData.balance;
    console.log('🔵 BYBIT FIXED: Available balance:', balance, 'USDT');

    if (balance < settings.order_amount_usd) {
      throw new Error(`Insufficient balance. Available: ${balance} USDT, Required: ${settings.order_amount_usd} USDT`);
    }

    // Получаем текущую цену символа
    const symbol = `${settings.base_asset}USDT`;
    const tickerResponse = await fetch(`https://api.bybit.com/v5/market/tickers?category=linear&symbol=${symbol}`);
    const tickerData = await tickerResponse.json();
    
    if (tickerData.retCode !== 0) {
      throw new Error(`Cannot get price for ${symbol}: ${tickerData.retMsg}`);
    }

    const currentPrice = parseFloat(tickerData.result.list[0].markPrice);
    console.log('🔵 BYBIT FIXED: Current price for', symbol, ':', currentPrice);

    // Рассчитываем количество (используем меньшее количество для тестирования)
    const orderValue = Math.min(settings.order_amount_usd, balance * 0.1); // Максимум 10% от баланса
    const quantity = (orderValue / currentPrice).toFixed(3);
    console.log('🔵 BYBIT FIXED: Order value:', orderValue, 'USDT, Quantity:', quantity);

    // Рассчитываем TP и SL цены
    const tpPrice = (currentPrice * (1 + settings.take_profit_percent / 100)).toFixed(2);
    const slPrice = (currentPrice * (1 - settings.stop_loss_percent / 100)).toFixed(2);

    console.log('🔵 BYBIT FIXED: TP Price:', tpPrice, 'SL Price:', slPrice);

    const timestamp = Date.now().toString();
    const orderData = {
      category: 'linear',
      symbol: symbol,
      side: 'Buy',
      orderType: 'Market',
      qty: quantity,
      takeProfit: tpPrice,
      stopLoss: slPrice,
      tpTriggerBy: 'MarkPrice',
      slTriggerBy: 'MarkPrice',
      timeInForce: 'IOC'
    };

    const body = JSON.stringify(orderData);
    const signature = await createBybitV5Signature(apiKey, apiSecret, timestamp, '', body);

    console.log('🔵 BYBIT FIXED: Placing order with data:', orderData);

    const response = await fetch('https://api.bybit.com/v5/order/create', {
      method: 'POST',
      headers: {
        'X-BAPI-API-KEY': apiKey,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': '5000',
        'Content-Type': 'application/json'
      },
      body: body
    });

    const result = await response.json();
    console.log('🔵 BYBIT FIXED: Order response:', JSON.stringify(result, null, 2));

    if (result.retCode !== 0) {
      throw new Error(`Bybit order error: ${result.retMsg} (Code: ${result.retCode})`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        order_id: result.result.orderId,
        symbol: symbol,
        side: 'Buy',
        quantity: quantity,
        price: currentPrice,
        tp_price: tpPrice,
        sl_price: slPrice,
        status: 'BYBIT ORDER PLACED ✅'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🔵 BYBIT FIXED: Order error:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: `Bybit order error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Получение позиций
async function handleBybitPositions(apiKey: string, apiSecret: string) {
  try {
    const timestamp = Date.now().toString();
    const queryString = 'category=linear&settleCoin=USDT';
    
    const signature = await createBybitV5Signature(apiKey, apiSecret, timestamp, queryString);
    
    const response = await fetch(`https://api.bybit.com/v5/position/list?${queryString}`, {
      method: 'GET',
      headers: {
        'X-BAPI-API-KEY': apiKey,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': '5000',
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    
    if (data.retCode !== 0) {
      throw new Error(`Bybit API error: ${data.retMsg}`);
    }

    const positions = data.result.list
      .filter((pos: any) => parseFloat(pos.size) > 0)
      .map((pos: any) => ({
        symbol: pos.symbol,
        side: pos.side,
        size: pos.size,
        entry_price: pos.avgPrice,
        mark_price: pos.markPrice,
        pnl: pos.unrealisedPnl,
        percentage: pos.unrealisedPnl ? ((parseFloat(pos.unrealisedPnl) / (parseFloat(pos.size) * parseFloat(pos.avgPrice))) * 100).toFixed(2) : '0'
      }));

    return new Response(
      JSON.stringify({ success: true, positions }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Закрытие позиций
async function handleBybitClosePositions(apiKey: string, apiSecret: string) {
  try {
    // Сначала получаем открытые позиции
    const positionsResponse = await handleBybitPositions(apiKey, apiSecret);
    const positionsData = await positionsResponse.json();
    
    if (!positionsData.success || !positionsData.positions.length) {
      return new Response(
        JSON.stringify({ success: true, closed_positions: 0, message: 'No positions to close' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let closedCount = 0;
    
    for (const position of positionsData.positions) {
      try {
        const timestamp = Date.now().toString();
        const orderData = {
          category: 'linear',
          symbol: position.symbol,
          side: position.side === 'Buy' ? 'Sell' : 'Buy',
          orderType: 'Market',
          qty: position.size,
          reduceOnly: true,
          timeInForce: 'IOC'
        };

        const body = JSON.stringify(orderData);
        const signature = await createBybitV5Signature(apiKey, apiSecret, timestamp, '', body);

        const response = await fetch('https://api.bybit.com/v5/order/create', {
          method: 'POST',
          headers: {
            'X-BAPI-API-KEY': apiKey,
            'X-BAPI-SIGN': signature,
            'X-BAPI-SIGN-TYPE': '2',
            'X-BAPI-TIMESTAMP': timestamp,
            'X-BAPI-RECV-WINDOW': '5000',
            'Content-Type': 'application/json'
          },
          body: body
        });

        const result = await response.json();
        
        if (result.retCode === 0) {
          closedCount++;
        }
        
      } catch (error) {
        console.error('Error closing position:', position.symbol, error);
      }
    }

    return new Response(
      JSON.stringify({ success: true, closed_positions: closedCount }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Отмена ордеров
async function handleBybitCancelOrders(apiKey: string, apiSecret: string) {
  try {
    const timestamp = Date.now().toString();
    const orderData = {
      category: 'linear',
      settleCoin: 'USDT'
    };

    const body = JSON.stringify(orderData);
    const signature = await createBybitV5Signature(apiKey, apiSecret, timestamp, '', body);

    const response = await fetch('https://api.bybit.com/v5/order/cancel-all', {
      method: 'POST',
      headers: {
        'X-BAPI-API-KEY': apiKey,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': '5000',
        'Content-Type': 'application/json'
      },
      body: body
    });

    const result = await response.json();
    
    if (result.retCode !== 0) {
      throw new Error(`Bybit API error: ${result.retMsg}`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        cancelled_orders: result.result?.list?.length || 0,
        message: 'All orders cancelled'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}