import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('🤖 AUTO FUNDING SCHEDULER: Starting automatic funding scheduler');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем всех пользователей с включенным фандинг ботом
    const { data: activeUsers, error: usersError } = await supabase
      .from('funding_bot_settings_2025_11_09_06_55')
      .select('*')
      .eq('enabled', true);

    if (usersError) {
      console.error('🤖 AUTO FUNDING SCHEDULER: Error getting users:', usersError);
      return new Response(
        JSON.stringify({ success: false, error: usersError.message }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🤖 AUTO FUNDING SCHEDULER: Found', activeUsers?.length || 0, 'active users');

    if (!activeUsers || activeUsers.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No active funding bot users found',
          scanned_users: 0
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const results = [];
    const currentTime = new Date();

    // Сканируем фандинги для каждого активного пользователя
    for (const user of activeUsers) {
      try {
        console.log('🤖 AUTO FUNDING SCHEDULER: Processing user:', user.user_id);
        
        // Проверяем расписание работы пользователя
        if (!isWithinWorkingHours(user, currentTime)) {
          console.log('🤖 AUTO FUNDING SCHEDULER: User', user.user_id, 'is outside working hours');
          continue;
        }

        // Проверяем интервал сканирования
        if (!shouldScanNow(user, currentTime)) {
          console.log('🤖 AUTO FUNDING SCHEDULER: User', user.user_id, 'scan interval not reached');
          continue;
        }

        const scanResult = await scanFundingForUser(user);
        results.push({
          user_id: user.user_id,
          ...scanResult
        });

        // Отправляем Telegram уведомления если есть возможности
        if (scanResult.opportunities && scanResult.opportunities.length > 0 && user.telegram_notifications) {
          await sendTelegramNotification(user, scanResult.opportunities);
        }

        // Обновляем время последнего сканирования
        await supabase
          .from('funding_bot_settings_2025_11_09_06_55')
          .update({ 
            last_scan_time: currentTime.toISOString(),
            updated_at: currentTime.toISOString()
          })
          .eq('user_id', user.user_id);

      } catch (error) {
        console.error('🤖 AUTO FUNDING SCHEDULER: Error processing user:', user.user_id, error);
        results.push({
          user_id: user.user_id,
          error: error.message
        });
      }
    }

    console.log('🤖 AUTO FUNDING SCHEDULER: Completed scan for', results.length, 'users');

    return new Response(
      JSON.stringify({
        success: true,
        scan_time: currentTime.toISOString(),
        scanned_users: results.length,
        results: results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ AUTO FUNDING SCHEDULER Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Проверка рабочих часов пользователя
function isWithinWorkingHours(userSettings: any, currentTime: Date): boolean {
  if (!userSettings.work_schedule_enabled) {
    return true; // Работает 24/7
  }

  const utc3Time = new Date(currentTime.getTime() + (3 * 60 * 60 * 1000)); // UTC+3
  const currentHour = utc3Time.getHours();
  
  const startHour = userSettings.work_start_hour || 0;
  const endHour = userSettings.work_end_hour || 23;

  if (startHour <= endHour) {
    return currentHour >= startHour && currentHour <= endHour;
  } else {
    // Переход через полночь
    return currentHour >= startHour || currentHour <= endHour;
  }
}

// Проверка интервала сканирования
function shouldScanNow(userSettings: any, currentTime: Date): boolean {
  if (!userSettings.last_scan_time) {
    return true; // Первое сканирование
  }

  const lastScanTime = new Date(userSettings.last_scan_time);
  const intervalMinutes = userSettings.scan_interval_minutes || 30; // По умолчанию 30 минут
  const timeDiff = (currentTime.getTime() - lastScanTime.getTime()) / (1000 * 60);

  return timeDiff >= intervalMinutes;
}

// Сканирование фандингов для конкретного пользователя
async function scanFundingForUser(userSettings: any) {
  console.log('🔍 FUNDING SCAN: Scanning for user with min rate:', userSettings.min_funding_rate);
  
  const allOpportunities = [];
  
  // Сканируем каждую биржу из настроек пользователя
  for (const exchange of userSettings.exchanges) {
    try {
      console.log('🔍 FUNDING SCAN: Scanning', exchange);
      
      let opportunities = [];
      
      if (exchange === 'binance') {
        opportunities = await scanBinanceFunding(userSettings.min_funding_rate);
      } else if (exchange === 'bybit') {
        opportunities = await scanBybitFunding(userSettings.min_funding_rate);
      } else if (exchange === 'gate') {
        opportunities = await scanGateFunding(userSettings.min_funding_rate);
      }
      
      // Добавляем информацию о бирже к каждой возможности
      opportunities.forEach(opp => {
        opp.exchange = exchange.toUpperCase();
        allOpportunities.push(opp);
      });
      
      console.log('🔍 FUNDING SCAN:', exchange, 'found', opportunities.length, 'opportunities');
      
    } catch (error) {
      console.error('🔍 FUNDING SCAN: Error scanning', exchange, ':', error);
    }
  }

  // Сортируем по абсолютному значению фандинга (от большего к меньшему)
  allOpportunities.sort((a, b) => Math.abs(parseFloat(b.funding_rate)) - Math.abs(parseFloat(a.funding_rate)));

  return {
    opportunities: allOpportunities.slice(0, 10), // Топ 10 возможностей
    total_found: allOpportunities.length,
    min_funding_rate: userSettings.min_funding_rate,
    exchanges_scanned: userSettings.exchanges
  };
}

// Сканирование Binance
async function scanBinanceFunding(minRate: number) {
  try {
    const response = await fetch('https://fapi.binance.com/fapi/v1/premiumIndex');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.lastFundingRate) * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.lastFundingRate) * 100).toFixed(3),
        next_funding_time: item.nextFundingTime,
        next_funding_utc3: formatTimeUTC3(item.nextFundingTime),
        mark_price: parseFloat(item.markPrice),
        exchange: 'BINANCE'
      }));
  } catch (error) {
    console.error('Error scanning Binance funding:', error);
    return [];
  }
}

// Сканирование Bybit
async function scanBybitFunding(minRate: number) {
  try {
    const response = await fetch('https://api.bybit.com/v5/market/tickers?category=linear');
    const data = await response.json();
    
    if (data.retCode !== 0) return [];
    
    return data.result.list
      .filter((item: any) => {
        const rate = parseFloat(item.fundingRate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.fundingRate || '0') * 100).toFixed(3),
        next_funding_time: item.nextFundingTime || getNextBybitFundingTime(),
        next_funding_utc3: formatTimeUTC3(item.nextFundingTime || getNextBybitFundingTime()),
        mark_price: parseFloat(item.markPrice || '0'),
        exchange: 'BYBIT'
      }));
  } catch (error) {
    console.error('Error scanning Bybit funding:', error);
    return [];
  }
}

// Сканирование Gate.io
async function scanGateFunding(minRate: number) {
  try {
    const response = await fetch('https://api.gateio.ws/api/v4/futures/usdt/tickers');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.funding_rate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.contract,
        funding_rate: (parseFloat(item.funding_rate || '0') * 100).toFixed(3),
        next_funding_time: item.funding_time || getNextGateFundingTime(),
        next_funding_utc3: formatTimeUTC3(item.funding_time || getNextGateFundingTime()),
        mark_price: parseFloat(item.mark_price || '0'),
        exchange: 'GATE'
      }));
  } catch (error) {
    console.error('Error scanning Gate funding:', error);
    return [];
  }
}

// Форматирование времени в UTC+3
function formatTimeUTC3(timestamp: any): string {
  try {
    let date;
    if (typeof timestamp === 'string') {
      date = new Date(timestamp);
    } else if (typeof timestamp === 'number') {
      date = new Date(timestamp);
    } else {
      return 'Неизвестно';
    }
    
    // Добавляем 3 часа для UTC+3
    const utc3Date = new Date(date.getTime() + (3 * 60 * 60 * 1000));
    
    return utc3Date.toLocaleString('ru-RU', {
      timeZone: 'Europe/Moscow',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  } catch (error) {
    console.error('Error formatting time:', error);
    return 'Ошибка времени';
  }
}

// Получение следующего времени фандинга для Bybit (каждые 8 часов: 00:00, 08:00, 16:00 UTC)
function getNextBybitFundingTime(): number {
  const now = new Date();
  const currentHour = now.getUTCHours();
  
  let nextHour;
  if (currentHour < 8) {
    nextHour = 8;
  } else if (currentHour < 16) {
    nextHour = 16;
  } else {
    nextHour = 24; // 00:00 следующего дня
  }
  
  const nextFunding = new Date(now);
  nextFunding.setUTCHours(nextHour % 24, 0, 0, 0);
  
  if (nextHour === 24) {
    nextFunding.setUTCDate(nextFunding.getUTCDate() + 1);
  }
  
  return nextFunding.getTime();
}

// Получение следующего времени фандинга для Gate.io (каждые 8 часов)
function getNextGateFundingTime(): number {
  return getNextBybitFundingTime(); // Аналогично Bybit
}

// Отправка Telegram уведомления
async function sendTelegramNotification(userSettings: any, opportunities: any[]) {
  if (!userSettings.telegram_chat_id) {
    console.log('🔍 TELEGRAM: No chat ID for user:', userSettings.user_id);
    return;
  }

  try {
    const telegramToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    if (!telegramToken) {
      console.log('🔍 TELEGRAM: No bot token configured');
      return;
    }

    const currentTimeUTC3 = new Date(Date.now() + (3 * 60 * 60 * 1000));

    // Формируем сообщение
    let message = `🤖 *АВТОМАТИЧЕСКИЙ СКАН ФАНДИНГОВ* 🤖\n\n`;
    message += `📊 Найдено ${opportunities.length} возможностей:\n\n`;

    opportunities.slice(0, 5).forEach((opp, index) => {
      const rate = parseFloat(opp.funding_rate);
      const emoji = rate > 0 ? '📈' : '📉';
      const direction = rate > 0 ? 'SHORT' : 'LONG';
      
      message += `${index + 1}. ${emoji} *${opp.symbol}* (${opp.exchange})\n`;
      message += `   💰 Фандинг: *${opp.funding_rate}%*\n`;
      message += `   🎯 Направление: *${direction}*\n`;
      message += `   💵 Цена: $${opp.mark_price}\n`;
      message += `   ⏰ Начисление: *${opp.next_funding_utc3}* (UTC+3)\n\n`;
    });

    message += `🕐 Время сканирования: *${currentTimeUTC3.toLocaleString('ru-RU')}* (UTC+3)\n`;
    message += `⚙️ Мин. фандинг: *${userSettings.min_funding_rate}%*\n`;
    message += `🔄 Автоматическое сканирование каждые *${userSettings.scan_interval_minutes || 30} минут*`;

    const telegramUrl = `https://api.telegram.org/bot${telegramToken}/sendMessage`;
    
    const response = await fetch(telegramUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: userSettings.telegram_chat_id,
        text: message,
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })
    });

    const result = await response.json();
    
    if (response.ok) {
      console.log('🔍 TELEGRAM: Auto message sent successfully to:', userSettings.telegram_chat_id);
    } else {
      console.error('🔍 TELEGRAM: Error sending auto message:', result);
    }

  } catch (error) {
    console.error('🔍 TELEGRAM: Auto notification error:', error);
  }
}