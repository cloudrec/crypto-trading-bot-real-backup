import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('⏰ HOURLY FUNDING CRON: Starting hourly funding scan');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем всех пользователей с включенным автоматическим сканированием
    const { data: activeUsers, error: usersError } = await supabase
      .from('funding_bot_settings_2025_11_09_06_55')
      .select('*')
      .eq('enabled', true)
      .eq('auto_scan_enabled', true);

    if (usersError) {
      console.error('⏰ HOURLY FUNDING CRON: Error getting users:', usersError);
      return new Response(
        JSON.stringify({ success: false, error: usersError.message }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('⏰ HOURLY FUNDING CRON: Found', activeUsers?.length || 0, 'active users with auto-scan enabled');

    if (!activeUsers || activeUsers.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No active auto-scan users found',
          scanned_users: 0,
          scan_time: new Date().toISOString()
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const results = [];
    const currentTime = new Date();
    const utc3Time = new Date(currentTime.getTime() + (3 * 60 * 60 * 1000));

    console.log('⏰ HOURLY FUNDING CRON: Current time UTC+3:', utc3Time.toISOString());

    // Сканируем фандинги для каждого активного пользователя
    for (const user of activeUsers) {
      try {
        console.log('⏰ HOURLY FUNDING CRON: Processing user:', user.user_id);
        
        // Проверяем расписание работы пользователя
        if (!isWithinWorkingHours(user, utc3Time)) {
          console.log('⏰ HOURLY FUNDING CRON: User', user.user_id, 'is outside working hours');
          results.push({
            user_id: user.user_id,
            status: 'skipped_outside_hours',
            working_hours: `${user.work_start_hour}:00 - ${user.work_end_hour}:00 UTC+3`
          });
          continue;
        }

        const scanResult = await scanFundingForUser(user);
        results.push({
          user_id: user.user_id,
          status: 'scanned',
          ...scanResult
        });

        // Отправляем Telegram уведомления если есть возможности
        if (scanResult.opportunities && scanResult.opportunities.length > 0 && user.telegram_notifications && user.telegram_chat_id) {
          await sendTelegramNotification(user, scanResult.opportunities, utc3Time);
          console.log('⏰ HOURLY FUNDING CRON: Telegram notification sent to user:', user.user_id);
        } else if (scanResult.opportunities && scanResult.opportunities.length > 0) {
          console.log('⏰ HOURLY FUNDING CRON: Opportunities found but no Telegram config for user:', user.user_id);
        }

        // Обновляем время последнего сканирования
        await supabase
          .from('funding_bot_settings_2025_11_09_06_55')
          .update({ 
            last_scan_time: currentTime.toISOString(),
            updated_at: currentTime.toISOString()
          })
          .eq('user_id', user.user_id);

      } catch (error) {
        console.error('⏰ HOURLY FUNDING CRON: Error processing user:', user.user_id, error);
        results.push({
          user_id: user.user_id,
          status: 'error',
          error: error.message
        });
      }
    }

    console.log('⏰ HOURLY FUNDING CRON: Completed hourly scan for', results.length, 'users');

    return new Response(
      JSON.stringify({
        success: true,
        scan_time: currentTime.toISOString(),
        scan_time_utc3: utc3Time.toISOString(),
        total_users: activeUsers.length,
        processed_users: results.length,
        results: results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ HOURLY FUNDING CRON Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Проверка рабочих часов пользователя (время в UTC+3)
function isWithinWorkingHours(userSettings: any, utc3Time: Date): boolean {
  if (!userSettings.work_schedule_enabled) {
    return true; // Работает 24/7
  }

  const currentHour = utc3Time.getHours();
  const startHour = userSettings.work_start_hour || 0;
  const endHour = userSettings.work_end_hour || 23;

  console.log(`⏰ HOURLY FUNDING CRON: Checking working hours for user ${userSettings.user_id}: current=${currentHour}, start=${startHour}, end=${endHour}`);

  if (startHour <= endHour) {
    return currentHour >= startHour && currentHour <= endHour;
  } else {
    // Переход через полночь
    return currentHour >= startHour || currentHour <= endHour;
  }
}

// Сканирование фандингов для конкретного пользователя
async function scanFundingForUser(userSettings: any) {
  console.log('🔍 HOURLY FUNDING SCAN: Scanning for user with min rate:', userSettings.min_funding_rate);
  
  const allOpportunities = [];
  
  // Сканируем каждую биржу из настроек пользователя
  for (const exchange of userSettings.exchanges) {
    try {
      console.log('🔍 HOURLY FUNDING SCAN: Scanning', exchange);
      
      let opportunities = [];
      
      if (exchange === 'binance') {
        opportunities = await scanBinanceFunding(userSettings.min_funding_rate);
      } else if (exchange === 'bybit') {
        opportunities = await scanBybitFunding(userSettings.min_funding_rate);
      } else if (exchange === 'gate') {
        opportunities = await scanGateFunding(userSettings.min_funding_rate);
      } else if (exchange === 'kucoin') {
        opportunities = await scanKuCoinFunding(userSettings.min_funding_rate);
      } else if (exchange === 'okx') {
        opportunities = await scanOKXFunding(userSettings.min_funding_rate);
      } else if (exchange === 'mexc') {
        opportunities = await scanMEXCFunding(userSettings.min_funding_rate);
      }
      
      // Добавляем информацию о бирже к каждой возможности
      opportunities.forEach(opp => {
        opp.exchange = exchange.toUpperCase();
        allOpportunities.push(opp);
      });
      
      console.log('🔍 HOURLY FUNDING SCAN:', exchange, 'found', opportunities.length, 'opportunities');
      
    } catch (error) {
      console.error('🔍 HOURLY FUNDING SCAN: Error scanning', exchange, ':', error);
    }
  }

  // Сортируем по абсолютному значению фандинга (от большего к меньшему)
  allOpportunities.sort((a, b) => Math.abs(parseFloat(b.funding_rate)) - Math.abs(parseFloat(a.funding_rate)));

  return {
    opportunities: allOpportunities.slice(0, 10), // Топ 10 возможностей
    total_found: allOpportunities.length,
    min_funding_rate: userSettings.min_funding_rate,
    exchanges_scanned: userSettings.exchanges
  };
}

// Сканирование Binance
async function scanBinanceFunding(minRate: number) {
  try {
    const response = await fetch('https://fapi.binance.com/fapi/v1/premiumIndex');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.lastFundingRate) * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.lastFundingRate) * 100).toFixed(3),
        next_funding_time: item.nextFundingTime,
        next_funding_utc3: formatTimeUTC3(item.nextFundingTime),
        mark_price: parseFloat(item.markPrice),
        exchange: 'BINANCE'
      }));
  } catch (error) {
    console.error('Error scanning Binance funding:', error);
    return [];
  }
}

// Сканирование Bybit
async function scanBybitFunding(minRate: number) {
  try {
    const response = await fetch('https://api.bybit.com/v5/market/tickers?category=linear');
    const data = await response.json();
    
    if (data.retCode !== 0) return [];
    
    return data.result.list
      .filter((item: any) => {
        const rate = parseFloat(item.fundingRate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.fundingRate || '0') * 100).toFixed(3),
        next_funding_time: item.nextFundingTime || getNextBybitFundingTime(),
        next_funding_utc3: formatTimeUTC3(item.nextFundingTime || getNextBybitFundingTime()),
        mark_price: parseFloat(item.markPrice || '0'),
        exchange: 'BYBIT'
      }));
  } catch (error) {
    console.error('Error scanning Bybit funding:', error);
    return [];
  }
}

// Сканирование Gate.io
async function scanGateFunding(minRate: number) {
  try {
    const response = await fetch('https://api.gateio.ws/api/v4/futures/usdt/tickers');
    const data = await response.json();
    
    return data
      .filter((item: any) => {
        const rate = parseFloat(item.funding_rate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.contract,
        funding_rate: (parseFloat(item.funding_rate || '0') * 100).toFixed(3),
        next_funding_time: item.funding_time || getNextGateFundingTime(),
        next_funding_utc3: formatTimeUTC3(item.funding_time || getNextGateFundingTime()),
        mark_price: parseFloat(item.mark_price || '0'),
        exchange: 'GATE'
      }));
  } catch (error) {
    console.error('Error scanning Gate funding:', error);
    return [];
  }
}

// Форматирование времени в киевское время (UTC+3)
function formatTimeUTC3(timestamp: any): string {
  try {
    let date;
    if (typeof timestamp === 'string') {
      date = new Date(timestamp);
    } else if (typeof timestamp === 'number') {
      date = new Date(timestamp);
    } else {
      return 'Неизвестно';
    }
    
    // Добавляем 3 часа для UTC+3
    const utc3Date = new Date(date.getTime() + (3 * 60 * 60 * 1000));
    
    return utc3Date.toLocaleString('ru-RU', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  } catch (error) {
    console.error('Error formatting time:', error);
    return 'Ошибка времени';
  }
}

// Получение следующего времени фандинга для Bybit (каждые 8 часов: 00:00, 08:00, 16:00 UTC)
function getNextBybitFundingTime(): number {
  const now = new Date();
  const currentHour = now.getUTCHours();
  
  let nextHour;
  if (currentHour < 8) {
    nextHour = 8;
  } else if (currentHour < 16) {
    nextHour = 16;
  } else {
    nextHour = 24; // 00:00 следующего дня
  }
  
  const nextFunding = new Date(now);
  nextFunding.setUTCHours(nextHour % 24, 0, 0, 0);
  
  if (nextHour === 24) {
    nextFunding.setUTCDate(nextFunding.getUTCDate() + 1);
  }
  
  return nextFunding.getTime();
}

// Получение следующего времени фандинга для Gate.io (каждые 8 часов)
function getNextGateFundingTime(): number {
  return getNextBybitFundingTime(); // Аналогично Bybit
}

// Отправка Telegram уведомления
async function sendTelegramNotification(userSettings: any, opportunities: any[], utc3Time: Date) {
  if (!userSettings.telegram_chat_id) {
    console.log('📱 TELEGRAM: No chat ID for user:', userSettings.user_id);
    return;
  }

  try {
    const telegramToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    if (!telegramToken) {
      console.log('📱 TELEGRAM: No bot token configured');
      return;
    }

    // Формируем сообщение
    let message = `🤖 *АВТОМАТИЧЕСКОЕ СКАНИРОВАНИЕ В ФОНЕ* 🤖\n\n`;
    message += `📊 Найдено ${opportunities.length} возможностей фандинга:\n\n`;

    opportunities.slice(0, 5).forEach((opp, index) => {
      const rate = parseFloat(opp.funding_rate);
      const emoji = rate > 0 ? '📈' : '📉';
      const direction = rate > 0 ? 'SHORT' : 'LONG';
      
      // Добавляем время начисления прямо в название пары
      message += `${index + 1}. ${emoji} *${opp.symbol}* (⏰ ${opp.next_funding_utc3}) - ${opp.exchange}\n`;
      message += `   💰 Фандинг: *${opp.funding_rate}%*\n`;
      message += `   🎯 Направление: *${direction}*\n`;
      message += `   💵 Цена: $${opp.mark_price}\n\n`;
    });

    message += `🕐 Время сканирования: *${utc3Time.toLocaleString('ru-RU')}* (киевское время)\n`;
    message += `⚙️ Мин. фандинг: *${userSettings.min_funding_rate}%*\n`;
    message += `🤖 Автоматическое сканирование в фоне каждый час\n`;
    message += `🔄 Расписание: ${userSettings.work_schedule_enabled ? `${userSettings.work_start_hour}:00-${userSettings.work_end_hour}:00` : '24/7'} (киевское время)`;

    const telegramUrl = `https://api.telegram.org/bot${telegramToken}/sendMessage`;
    
    const response = await fetch(telegramUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: userSettings.telegram_chat_id,
        text: message,
        parse_mode: 'Markdown',
        disable_web_page_preview: true
      })
    });

    const result = await response.json();
    
    if (response.ok) {
      console.log('📱 TELEGRAM: Hourly auto message sent successfully to:', userSettings.telegram_chat_id);
    } else {
      console.error('📱 TELEGRAM: Error sending hourly auto message:', result);
    }

  } catch (error) {
    console.error('📱 TELEGRAM: Hourly auto notification error:', error);
  }
}

// Сканирование KuCoin
async function scanKuCoinFunding(minRate: number) {
  try {
    const response = await fetch('https://api-futures.kucoin.com/api/v1/contracts/active');
    const data = await response.json();
    
    if (data.code !== '200000') return [];
    
    const fundingOpportunities = [];
    
    for (const contract of data.data) {
      try {
        const fundingResponse = await fetch(`https://api-futures.kucoin.com/api/v1/contract/${contract.symbol}`);
        const fundingData = await fundingResponse.json();
        
        if (fundingData.code === '200000' && fundingData.data.fundingFeeRate) {
          const rate = parseFloat(fundingData.data.fundingFeeRate) * 100;
          if (Math.abs(rate) >= minRate) {
            fundingOpportunities.push({
              symbol: contract.symbol,
              funding_rate: rate.toFixed(3),
              next_funding_time: fundingData.data.nextFundingRateTime || getNextKuCoinFundingTime(),
              next_funding_utc3: formatTimeUTC3(fundingData.data.nextFundingRateTime || getNextKuCoinFundingTime()),
              mark_price: parseFloat(contract.markPrice || '0'),
              exchange: 'KUCOIN'
            });
          }
        }
      } catch (error) {
        console.error('Error getting KuCoin funding for', contract.symbol, ':', error);
      }
    }
    
    return fundingOpportunities;
  } catch (error) {
    console.error('Error scanning KuCoin funding:', error);
    return [];
  }
}

// Сканирование OKX
async function scanOKXFunding(minRate: number) {
  try {
    const response = await fetch('https://www.okx.com/api/v5/public/funding-rate?instType=SWAP');
    const data = await response.json();
    
    if (data.code !== '0') return [];
    
    return data.data
      .filter((item: any) => {
        const rate = parseFloat(item.fundingRate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.instId,
        funding_rate: (parseFloat(item.fundingRate || '0') * 100).toFixed(3),
        next_funding_time: item.nextFundingTime || getNextOKXFundingTime(),
        next_funding_utc3: formatTimeUTC3(item.nextFundingTime || getNextOKXFundingTime()),
        mark_price: parseFloat(item.markPx || '0'),
        exchange: 'OKX'
      }));
  } catch (error) {
    console.error('Error scanning OKX funding:', error);
    return [];
  }
}

// Сканирование MEXC
async function scanMEXCFunding(minRate: number) {
  try {
    const response = await fetch('https://contract.mexc.com/api/v1/contract/funding_rate');
    const data = await response.json();
    
    if (data.code !== 0) return [];
    
    return data.data
      .filter((item: any) => {
        const rate = parseFloat(item.fundingRate || '0') * 100;
        return Math.abs(rate) >= minRate;
      })
      .map((item: any) => ({
        symbol: item.symbol,
        funding_rate: (parseFloat(item.fundingRate || '0') * 100).toFixed(3),
        next_funding_time: item.nextSettleTime || getNextMEXCFundingTime(),
        next_funding_utc3: formatTimeUTC3(item.nextSettleTime || getNextMEXCFundingTime()),
        mark_price: parseFloat(item.markPrice || '0'),
        exchange: 'MEXC'
      }));
  } catch (error) {
    console.error('Error scanning MEXC funding:', error);
    return [];
  }
}

// Получение следующего времени фандинга для KuCoin (каждые 8 часов)
function getNextKuCoinFundingTime(): number {
  return getNextBybitFundingTime(); // Аналогично Bybit
}

// Получение следующего времени фандинга для OKX (каждые 8 часов)
function getNextOKXFundingTime(): number {
  return getNextBybitFundingTime(); // Аналогично Bybit
}

// Получение следующего времени фандинга для MEXC (каждые 8 часов)
function getNextMEXCFundingTime(): number {
  return getNextBybitFundingTime(); // Аналогично Bybit
}