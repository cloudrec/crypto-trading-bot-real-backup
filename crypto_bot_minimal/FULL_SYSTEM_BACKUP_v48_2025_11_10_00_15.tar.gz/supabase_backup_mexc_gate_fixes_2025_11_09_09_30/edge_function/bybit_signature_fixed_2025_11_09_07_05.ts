import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, user_id } = await req.json();
    
    console.log('🔵 BYBIT V5: Starting action:', action, 'for user:', user_id);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем ТОЛЬКО Bybit API ключи
    const { data: apiKeys, error: keysError } = await supabase
      .from('api_keys_dev')
      .select('*')
      .eq('user_id', user_id)
      .eq('exchange', 'bybit')
      .single();

    if (keysError || !apiKeys) {
      console.log('🔵 BYBIT V5: No Bybit API keys found');
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Bybit API ключи не найдены',
          debug: {
            user_id,
            keys_error: keysError?.message,
            function: 'bybit_signature_fixed_2025_11_09_07_05'
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('🔵 BYBIT V5: API keys found');
    console.log('🔵 BYBIT V5: API Key length:', apiKeys.api_key?.length);
    console.log('🔵 BYBIT V5: Secret length:', apiKeys.api_secret?.length);

    // Обработка разных действий
    switch (action) {
      case 'get_balance':
        return await handleBybitBalance(apiKeys);
      
      case 'place_order_with_tp_sl':
        return await handleBybitOrder(apiKeys);
      
      case 'get_positions':
        return await handleBybitPositions(apiKeys);
      
      case 'close_positions':
      case 'close_all_positions':
        return await handleBybitClosePositions(apiKeys);
      
      case 'cancel_orders':
      case 'cancel_all_orders':
        return await handleBybitCancelOrders(apiKeys);
      
      default:
        return new Response(
          JSON.stringify({ success: false, error: `Неизвестное действие: ${action}` }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }

  } catch (error) {
    console.error('❌ BYBIT V5 Error:', error.message);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        debug: {
          function: 'bybit_signature_fixed_2025_11_09_07_05',
          timestamp: new Date().toISOString()
        }
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Правильная подпись для Bybit V5 API
async function createBybitV5Signature(timestamp: string, apiKey: string, recvWindow: string, queryString: string, apiSecret: string) {
  // Для GET запросов: timestamp + apiKey + recvWindow + queryString
  // Для POST запросов: timestamp + apiKey + recvWindow + body
  const paramString = timestamp + apiKey + recvWindow + queryString;
  
  console.log('🔵 BYBIT V5: Creating signature for:', paramString.substring(0, 50) + '...');
  
  const encoder = new TextEncoder();
  const keyData = encoder.encode(apiSecret);
  const messageData = encoder.encode(paramString);
  
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData);
  const hexSignature = Array.from(new Uint8Array(signature))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
    
  console.log('🔵 BYBIT V5: Signature created:', hexSignature.substring(0, 16) + '...');
  return hexSignature;
}

// BYBIT БАЛАНС с правильной подписью
async function handleBybitBalance(apiKeys: any) {
  console.log('🔵 BYBIT V5: Getting balance');
  
  try {
    const timestamp = Date.now().toString();
    const recvWindow = '5000';
    const queryString = 'category=unified';
    
    const signature = await createBybitV5Signature(
      timestamp, 
      apiKeys.api_key, 
      recvWindow, 
      queryString, 
      apiKeys.api_secret
    );
    
    const url = `https://api.bybit.com/v5/account/wallet-balance?${queryString}`;
    
    console.log('🔵 BYBIT V5: Making request to:', url);
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-BAPI-API-KEY': apiKeys.api_key,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': recvWindow,
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();
    console.log('🔵 BYBIT V5: Response status:', response.status);
    console.log('🔵 BYBIT V5: Response:', JSON.stringify(data).substring(0, 200) + '...');

    if (response.ok && data.retCode === 0) {
      const usdtBalance = data.result?.list?.[0]?.coin?.find((coin: any) => coin.coin === 'USDT');
      const balance = usdtBalance?.availableToWithdraw || '0.00';
      
      console.log('🔵 BYBIT V5: USDT Balance:', balance);
      
      return new Response(
        JSON.stringify({
          success: true,
          data: {
            available_balance: balance,
            currency: 'USDT',
            status: 'BYBIT LIVE ✅',
            exchange: 'BYBIT',
            debug: {
              function: 'bybit_signature_fixed_2025_11_09_07_05',
              api_version: 'V5',
              response_code: data.retCode
            }
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      throw new Error(`Bybit API error: ${data.retMsg || 'Unknown error'} (Code: ${data.retCode})`);
    }
  } catch (error) {
    console.error('🔵 BYBIT V5: Balance error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: `Bybit balance error: ${error.message}`,
        debug: {
          function: 'bybit_signature_fixed_2025_11_09_07_05',
          api_version: 'V5'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// BYBIT ПОЗИЦИИ
async function handleBybitPositions(apiKeys: any) {
  console.log('🔵 BYBIT V5: Getting positions');
  
  try {
    const timestamp = Date.now().toString();
    const recvWindow = '5000';
    const queryString = 'category=linear';
    
    const signature = await createBybitV5Signature(
      timestamp, 
      apiKeys.api_key, 
      recvWindow, 
      queryString, 
      apiKeys.api_secret
    );
    
    const url = `https://api.bybit.com/v5/position/list?${queryString}`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-BAPI-API-KEY': apiKeys.api_key,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': recvWindow,
        'Content-Type': 'application/json'
      }
    });
    
    const data = await response.json();

    if (response.ok && data.retCode === 0) {
      const activePositions = data.result?.list?.filter((pos: any) => parseFloat(pos.size) > 0) || [];
      console.log('🔵 BYBIT V5: Found', activePositions.length, 'active positions');
      
      return new Response(
        JSON.stringify({
          success: true,
          data: {
            positions: activePositions.map((pos: any) => ({
              symbol: pos.symbol,
              size: pos.size,
              side: pos.side,
              unrealizedPnl: pos.unrealisedPnl,
              markPrice: pos.markPrice,
              avgPrice: pos.avgPrice,
              exchange: 'BYBIT'
            })),
            exchange: 'BYBIT'
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      throw new Error(`Bybit positions error: ${data.retMsg || 'Unknown error'}`);
    }
  } catch (error) {
    console.error('🔵 BYBIT V5: Positions error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: `Bybit positions error: ${error.message}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// BYBIT ОРДЕР
async function handleBybitOrder(apiKeys: any) {
  console.log('🔵 BYBIT V5: Placing order');
  
  const symbol = 'BTCUSDT';
  const qty = '10';
  
  try {
    // Получаем текущую цену
    const priceResponse = await fetch(`https://api.bybit.com/v5/market/tickers?category=linear&symbol=${symbol}`);
    const priceData = await priceResponse.json();
    const currentPrice = parseFloat(priceData.result?.list?.[0]?.lastPrice || '0');
    
    const tpPrice = (currentPrice * 1.02).toFixed(2);
    const slPrice = (currentPrice * 0.98).toFixed(2);
    
    console.log('🔵 BYBIT V5: Prices:', { currentPrice, tpPrice, slPrice });

    const timestamp = Date.now().toString();
    const recvWindow = '5000';
    
    const orderData = {
      category: 'linear',
      symbol: symbol,
      side: 'Buy',
      orderType: 'Market',
      qty: qty,
      takeProfit: tpPrice,
      stopLoss: slPrice
    };
    
    const body = JSON.stringify(orderData);
    
    const signature = await createBybitV5Signature(
      timestamp, 
      apiKeys.api_key, 
      recvWindow, 
      body, 
      apiKeys.api_secret
    );
    
    console.log('🔵 BYBIT V5: Making order request');
    
    const response = await fetch('https://api.bybit.com/v5/order/create', {
      method: 'POST',
      headers: {
        'X-BAPI-API-KEY': apiKeys.api_key,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': recvWindow,
        'Content-Type': 'application/json'
      },
      body: body
    });

    const data = await response.json();
    console.log('🔵 BYBIT V5: Order response:', data);

    if (response.ok && data.retCode === 0) {
      return new Response(
        JSON.stringify({
          success: true,
          data: {
            message: `BYBIT ордер размещен: ${symbol}`,
            order_id: data.result?.orderId,
            symbol: symbol,
            quantity: qty,
            current_price: currentPrice,
            tp_price: tpPrice,
            sl_price: slPrice,
            exchange: 'BYBIT',
            debug: {
              function: 'bybit_signature_fixed_2025_11_09_07_05',
              api_version: 'V5'
            }
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      throw new Error(`Bybit order error: ${data.retMsg || 'Unknown error'} (Code: ${data.retCode})`);
    }

  } catch (error) {
    console.error('🔵 BYBIT V5: Order error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: `Bybit order error: ${error.message}`,
        debug: {
          function: 'bybit_signature_fixed_2025_11_09_07_05',
          api_version: 'V5'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// BYBIT ЗАКРЫТИЕ ПОЗИЦИЙ
async function handleBybitClosePositions(apiKeys: any) {
  console.log('🔵 BYBIT V5: Closing positions');
  
  try {
    // Получаем позиции
    const positionsResult = await handleBybitPositions(apiKeys);
    const positionsText = await positionsResult.text();
    const positionsData = JSON.parse(positionsText);
    
    if (!positionsData.success || !positionsData.data.positions) {
      return new Response(
        JSON.stringify({
          success: true,
          data: {
            message: 'BYBIT позиции закрыты: 0',
            closed_positions: 0,
            exchange: 'BYBIT'
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let closedCount = 0;
    const positions = positionsData.data.positions;

    for (const position of positions) {
      try {
        const timestamp = Date.now().toString();
        const recvWindow = '5000';
        
        const orderData = {
          category: 'linear',
          symbol: position.symbol,
          side: position.side === 'Buy' ? 'Sell' : 'Buy',
          orderType: 'Market',
          qty: position.size,
          reduceOnly: true
        };
        
        const body = JSON.stringify(orderData);
        
        const signature = await createBybitV5Signature(
          timestamp, 
          apiKeys.api_key, 
          recvWindow, 
          body, 
          apiKeys.api_secret
        );
        
        const response = await fetch('https://api.bybit.com/v5/order/create', {
          method: 'POST',
          headers: {
            'X-BAPI-API-KEY': apiKeys.api_key,
            'X-BAPI-SIGN': signature,
            'X-BAPI-SIGN-TYPE': '2',
            'X-BAPI-TIMESTAMP': timestamp,
            'X-BAPI-RECV-WINDOW': recvWindow,
            'Content-Type': 'application/json'
          },
          body: body
        });

        const data = await response.json();
        
        if (response.ok && data.retCode === 0) {
          closedCount++;
        }
      } catch (e) {
        console.log('🔵 BYBIT V5: Error closing position:', e);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        data: {
          message: `BYBIT позиции закрыты: ${closedCount}`,
          closed_positions: closedCount,
          exchange: 'BYBIT'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('🔵 BYBIT V5: Close positions error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: `Bybit close positions error: ${error.message}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// BYBIT ОТМЕНА ОРДЕРОВ
async function handleBybitCancelOrders(apiKeys: any) {
  console.log('🔵 BYBIT V5: Canceling orders');
  
  try {
    const timestamp = Date.now().toString();
    const recvWindow = '5000';
    
    const orderData = {
      category: 'linear'
    };
    
    const body = JSON.stringify(orderData);
    
    const signature = await createBybitV5Signature(
      timestamp, 
      apiKeys.api_key, 
      recvWindow, 
      body, 
      apiKeys.api_secret
    );
    
    const response = await fetch('https://api.bybit.com/v5/order/cancel-all', {
      method: 'POST',
      headers: {
        'X-BAPI-API-KEY': apiKeys.api_key,
        'X-BAPI-SIGN': signature,
        'X-BAPI-SIGN-TYPE': '2',
        'X-BAPI-TIMESTAMP': timestamp,
        'X-BAPI-RECV-WINDOW': recvWindow,
        'Content-Type': 'application/json'
      },
      body: body
    });

    const data = await response.json();

    if (response.ok && data.retCode === 0) {
      return new Response(
        JSON.stringify({
          success: true,
          data: {
            message: 'BYBIT ордера отменены',
            cancelled_orders: data.result?.list?.length || 0,
            exchange: 'BYBIT'
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      throw new Error(`Bybit cancel orders error: ${data.retMsg || 'Unknown error'}`);
    }

  } catch (error) {
    console.error('🔵 BYBIT V5: Cancel orders error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: `Bybit cancel orders error: ${error.message}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}