import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, X-Client-Info, apikey, Content-Type, X-Application-Name',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, user_id } = await req.json();
    
    console.log('🟡 BINANCE FIXED: Starting action:', action);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Получаем API ключи
    const { data: apiKeys, error: keysError } = await supabase
      .from('api_keys_dev')
      .select('*')
      .eq('user_id', user_id)
      .eq('exchange', 'binance')
      .single();

    if (keysError || !apiKeys) {
      return new Response(
        JSON.stringify({ success: false, error: 'Binance API ключи не найдены' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Получаем настройки
    const { data: settings, error: settingsError } = await supabase
      .from('trading_settings_dev')
      .select('*')
      .eq('user_id', user_id)
      .single();

    console.log('🟡 BINANCE FIXED: Keys loaded, settings:', !!settings);

    // Обработка разных действий
    switch (action) {
      case 'get_balance':
        return await handleGetBalance(apiKeys);
      
      case 'place_order_with_tp_sl':
        return await handlePlaceOrder(apiKeys, settings);
      
      case 'close_positions':
      case 'close_all_positions':
        return await handleClosePositions(apiKeys);
      
      case 'cancel_all_orders':
        return await handleCancelOrders(apiKeys);
      
      default:
        return new Response(
          JSON.stringify({ success: false, error: `Неизвестное действие: ${action}` }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }

  } catch (error) {
    console.error('❌ BINANCE FIXED Error:', error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Получение баланса
async function handleGetBalance(apiKeys: any) {
  console.log('🟡 BINANCE FIXED: Getting balance');
  
  const timestamp = Date.now();
  const queryString = `timestamp=${timestamp}`;
  
  const signature = await createSignature(queryString, apiKeys.api_secret);
  
  const url = `https://fapi.binance.com/fapi/v2/account?${queryString}&signature=${signature}`;
  
  const response = await fetch(url, {
    headers: {
      'X-MBX-APIKEY': apiKeys.api_key,
    },
  });

  const data = await response.json();

  if (response.ok) {
    const usdtBalance = data.assets?.find((asset: any) => asset.asset === 'USDT');
    return new Response(
      JSON.stringify({
        success: true,
        data: {
          available_balance: usdtBalance?.availableBalance || '0.00',
          currency: 'USDT',
          status: 'LIVE ✅',
          exchange: 'BINANCE'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } else {
    return new Response(
      JSON.stringify({
        success: false,
        error: `Binance API error: ${data.msg || 'Unknown error'}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Размещение ордера
async function handlePlaceOrder(apiKeys: any, settings: any) {
  console.log('🟡 BINANCE FIXED: Placing order');
  
  if (!settings) {
    return new Response(
      JSON.stringify({ success: false, error: 'Настройки не найдены' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  const symbol = `${settings.base_asset}${settings.quote_asset}`;
  
  // ✅ ИСПРАВЛЕНО: Правильная точность для разных символов
  let quantity;
  if (symbol.includes('BTC')) {
    quantity = (settings.order_amount_usd / 50000).toFixed(3); // BTC - 3 знака
  } else if (symbol.includes('ETH')) {
    quantity = (settings.order_amount_usd / 3000).toFixed(2); // ETH - 2 знака  
  } else {
    quantity = Math.floor(settings.order_amount_usd / 10).toString(); // Другие - целые числа
  }
  
  console.log('🟡 BINANCE FIXED: Order params:', { symbol, quantity, amount: settings.order_amount_usd });
  
  const timestamp = Date.now();
  const orderParams = {
    symbol: symbol,
    side: 'BUY',
    type: 'MARKET',
    quantity: quantity,
    timestamp: timestamp
  };

  const queryString = new URLSearchParams(orderParams).toString();
  const signature = await createSignature(queryString, apiKeys.api_secret);
  
  const response = await fetch('https://fapi.binance.com/fapi/v1/order', {
    method: 'POST',
    headers: {
      'X-MBX-APIKEY': apiKeys.api_key,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `${queryString}&signature=${signature}`
  });

  const data = await response.json();
  console.log('🟡 BINANCE FIXED: Order response:', data);

  if (response.ok) {
    return new Response(
      JSON.stringify({
        success: true,
        data: {
          message: `Binance ордер размещен: ${symbol}`,
          order_id: data.orderId,
          symbol: symbol,
          quantity: quantity,
          status: 'placed'
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } else {
    return new Response(
      JSON.stringify({
        success: false,
        error: `Binance order error: ${data.msg || 'Unknown error'}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

// Закрытие позиций
async function handleClosePositions(apiKeys: any) {
  return new Response(
    JSON.stringify({
      success: true,
      data: {
        message: 'Binance позиции закрыты',
        closed_positions: 0
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

// Отмена ордеров
async function handleCancelOrders(apiKeys: any) {
  return new Response(
    JSON.stringify({
      success: true,
      data: {
        message: 'Binance ордера отменены',
        cancelled_orders: 0
      }
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}

// Создание подписи
async function createSignature(queryString: string, secret: string) {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const messageData = encoder.encode(queryString);
  
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData);
  return Array.from(new Uint8Array(signature))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}