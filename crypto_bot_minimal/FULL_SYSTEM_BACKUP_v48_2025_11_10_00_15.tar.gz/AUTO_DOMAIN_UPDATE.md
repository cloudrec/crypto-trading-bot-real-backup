# 🤖 Автоматическое обновление домена fundbot.win

## 🚨 Проблема
После каждой сборки проекта адрес меняется, и нужно вручную обновлять CNAME в Cloudflare.

## ✅ Решение
Автоматический скрипт, который обновляет CNAME после каждой публикации.

## 🔧 Настройка автоматического обновления

### Шаг 1: Получите API ключи Cloudflare

1. **Войдите в Cloudflare Dashboard:** https://dash.cloudflare.com
2. **Перейдите в:** My Profile → API Tokens
3. **Создайте Custom Token** с правами:
   ```
   Permissions:
   - Zone:Zone:Read
   - Zone:DNS:Edit
   
   Zone Resources:
   - Include: Specific zone: fundbot.win
   ```
4. **Скопируйте API Token**

### Шаг 2: Получите Zone ID

1. **В Cloudflare Dashboard** выберите домен `fundbot.win`
2. **В правой панели** найдите "Zone ID"
3. **Скопируйте Zone ID**

### Шаг 3: Настройте скрипт

Отредактируйте файл `update_domain.sh`:

```bash
# Замените эти значения на ваши:
CLOUDFLARE_EMAIL="cloudkroter@gmail.com"
CLOUDFLARE_API_KEY="ваш_api_token_здесь"
ZONE_ID="ваш_zone_id_здесь"
```

### Шаг 4: Сделайте скрипт исполняемым

```bash
chmod +x update_domain.sh
```

## 🚀 Использование

### Автоматический запуск после публикации:
```bash
# После каждой команды publish_website запускайте:
./update_domain.sh
```

### Ручной запуск:
```bash
# Если нужно обновить домен вручную:
./update_domain.sh
```

## 📋 Что делает скрипт:

1. ✅ **Находит текущий адрес** Skywork проекта
2. ✅ **Получает ID CNAME записи** из Cloudflare
3. ✅ **Обновляет CNAME** на новый адрес
4. ✅ **Подтверждает успешное обновление**

## 🎯 Результат:

- **fundbot.win** всегда указывает на актуальный адрес
- **Автоматическое обновление** после каждой сборки
- **Стабильный домен** для пользователей

## 🔧 Альтернативное решение (проще):

### Ручное обновление в Cloudflare:

**Текущий актуальный адрес:** `zvxhybhst3.skywork.website`

1. **Cloudflare Dashboard** → `fundbot.win`
2. **DNS → Records**
3. **Редактировать CNAME:**
   ```
   Name: @
   Target: zvxhybhst3.skywork.website
   Proxy: ON (🟠)
   ```
4. **Save**

**После каждой публикации проекта я буду сообщать новый адрес для обновления CNAME.**

---

## 📞 Поддержка

Если нужна помощь с настройкой:
1. Предоставьте API Token и Zone ID
2. Я помогу настроить автоматическое обновление
3. Или буду сообщать новые адреса для ручного обновления